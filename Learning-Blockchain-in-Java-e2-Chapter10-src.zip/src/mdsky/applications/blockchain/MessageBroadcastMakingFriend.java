package mdsky.applications.blockchain;

import java.security.PrivateKey;
import java.security.PublicKey;

public final class MessageBroadcastMakingFriend extends MessageSigned
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private String info = null;
	private byte[] signature = null;
	private PublicKey sender = null;
	private String name = null;
	private String uniqueHashID;
	private long timeStamp = 0;
	private String IP;
	
	public MessageBroadcastMakingFriend(PrivateKey pk, PublicKey sender, String name, String IP)
	{
		this.info = Message.JCOIN_MESSAGE;
		signature = UtilityMethods.generateSignature(pk, this.info);
		this.sender = sender;
		this.name = name;
		this.timeStamp = UtilityMethods.getTimeStamp();
		String v = UtilityMethods.getKeyString(sender) + name + UtilityMethods.getUniqueNumber() + this.timeStamp;
		this.uniqueHashID = UtilityMethods.messageDigestSHA256_toString(v);
		this.IP = IP;
	}
	
	public String getMessageBody(){
		return this.info;
	}

	public boolean isValid()
	{
		return UtilityMethods.verifySignature(this.getSenderKey(), signature, this.info);
	}
	
	public int getMessageType(){
		return Message.ADDRESS_BROADCAST_MAKING_FRIEND;
	}
	
	public PublicKey getSenderKey()
	{
		return this.sender;
	}
	
	public boolean isForBroadcast(){
		return true;
	}
	
	public String getName(){
		return this.name;
	}
	
	public KeyNamePair getKeyNamePair(){
		KeyNamePair kp = new KeyNamePair(this.getSenderKey(), this.getName());
		return kp;
	}
	
	public String getMessageHashID(){
		return this.uniqueHashID;
	}
	
	public long getTimeStamp(){
		return this.timeStamp;
	}
	
	public String getIP(){
		return this.IP;
	}
}
