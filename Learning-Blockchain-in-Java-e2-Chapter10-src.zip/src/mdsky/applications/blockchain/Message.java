package mdsky.applications.blockchain;

import java.security.PublicKey;

public abstract class Message implements java.io.Serializable
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	
	public static final int ID = 0;
	
	public static final int TEXT_BROADCAST = 1;
	public static final int TEXT_PRIVATE = 2;
	public static final int TEXT_PRIVATE_CLOSE_CONNECTION = 3;
	
	public static final int TRANSACTION_BROADCAST = 10;
	
	public static final int BLOCK_BROADCAST = 20;
	public static final int BLOCK_PRIVATE = 21;
	public static final int BLOCK_ASK_PRIVATE = 22;
	public static final int BLOCK_ASK_BROADCAST = 23;
	
	public static final int BLOCKCHAIN_BROADCAST = 3;
	public static final int BLOCKCHAIN_PRIVATE = 31;
	public static final int BLOCKCHAIN_ASK_BROADCAST = 33;
	
	public static final int ADDRESS_BROADCAST_MAKING_FRIEND = 40;
	public static final int ADDRESS_PRIVATE = 41;
	public static final int ADDRESS_ASK_BROADCAST = 42;
	
	//a message used to testify if the message transportation is tampered
	public static final String JCOIN_MESSAGE = "This package is from mdsky.";
	
	public abstract int getMessageType();
	
	public static final String TEXT_CLOSE = "CLOSE_me";
	public static final String TEXT_ASK_ADDRESSES = "TEXT_QUERY_ADDRESSES";

	//the message body
	public abstract Object getMessageBody();
	public abstract boolean isForBroadcast();
	
	//--- Methods added in Chapter 9
	
	//a unique ID of this message
	public abstract String getMessageHashID();
	//time stamp of the message: records when the message is created.
	public abstract long getTimeStamp();
	public abstract PublicKey getSenderKey();

	/**
	 * By default, a message sent by the peer won't be processed again by the same peer.
	 * However, if this method returns true, then this message will be processed again by the same peer.
	 * @return
	 */
	protected boolean selfMessageAllowed(){
		return false;
	}
}
