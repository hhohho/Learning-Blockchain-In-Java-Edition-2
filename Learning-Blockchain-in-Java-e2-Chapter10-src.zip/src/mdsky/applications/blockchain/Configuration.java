package mdsky.applications.blockchain;

/**
 * This class is written to demonstrate the idea: settings should be grouped for centralized management.
 * In this blockchain package, there are other settings are not included, however.
 * @author hzhou
 *
 */
public final class Configuration 
{
	private static String KEY_LOCATION = "keys";
	public static final String keyLocation(){
		return Configuration.KEY_LOCATION;
	}

	private static String HASH_ALGORITHM = "SHA-256";
	public static final String hashAlgorithm(){
		return Configuration.HASH_ALGORITHM;
	}
	
	private static final String SIGNATURE_ALGORITHM = "SHA256withRSA";
	public static final String signatureAlgorithm(){
		return Configuration.SIGNATURE_ALGORITHM;
	}
	
	private static final String KEYPAIR_ALGORITHM = "RSA";
	public static final String keyPairAlgorithm(){
		return Configuration.KEYPAIR_ALGORITHM;
	}
	
	private static final int PORT = 1117;
	public static final int networkPort(){
		return Configuration.PORT;
	}
	
	private static final int BLOCK_MINING_DIFFICULTY_LEVEL = 20;
	public static final int blockMiningDifficultyLevel(){
		return Configuration.BLOCK_MINING_DIFFICULTY_LEVEL;
	}
	
	private static int SIGN_IN_BONUS_USERS_LIMIT = 4;
	public static final int genesisMiner_signInBonusUsersLimit(){
		return Configuration.SIGN_IN_BONUS_USERS_LIMIT;
	}
	
	private static int SELF_BLOCKS_TO_MINE_LIMIT = 2;
	public static final int genesisMiner_selfBlocksToMineLimit(){
		return Configuration.SELF_BLOCKS_TO_MINE_LIMIT;
	}
	
	private static int BLOCK_TRANSACTION_UPPER_LIMIT = 100;
	public static final int blockTransactionNumberUpperLimit(){
		return Configuration.BLOCK_TRANSACTION_UPPER_LIMIT;
	}
	
	private static int BLOCK_TRANSACTION_LOWER_LIMIT = 2;
	public static final int blockTransactionNumberLowerLimit(){
		return Configuration.BLOCK_TRANSACTION_LOWER_LIMIT;
	}
	
	private static double MINING_REWARD = 100.0;
	public static final double blockMiningReward(){
		return Configuration.MINING_REWARD;
	}
	
	private static long MESSAGE_BURIED_TIME_LIMIT = 10 * 24 * 60 * 60 * 1000;
	public static final long messageBuriedTimeLimit(){
		return Configuration.MESSAGE_BURIED_TIME_LIMIT;
	}
	
	// The following variables and methods are added in Chapter 9
	private static int THREAD_SLEEP_TIME_SHORT = 100;
	public static final int threadSleepTimeShort(){
		return Configuration.THREAD_SLEEP_TIME_SHORT;
	}
	private static int THREAD_SLEEP_TIME_MEDIUM = 250;
	public static final int threadSleepTimeMedium(){
		return THREAD_SLEEP_TIME_MEDIUM;
	}
	private static int THREAD_SLEEP_TIME_LONG = 1000;
	public static final int threadSleepTimeLong(){
		return THREAD_SLEEP_TIME_LONG;
	}
	private static int LOG_BAR = 0;
	/**
	 * If it is higher than 10, then no log message can be displayed.
	 * @return
	 */
	public static final int logBar(){
		return LOG_BAR;
	}
	private static int LOG_MAX = 10;
	public static final int logMax(){
		return LOG_MAX;
	}
	/**
	 * Log message will only be displayed when LOG_BAR <= 0;
	 * @return
	 */
	public static final int logMin(){
		return 0;
	}
	
	public static final int logMedium(){
		return 5;
	}
}

