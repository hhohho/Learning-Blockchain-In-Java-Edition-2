package mdsky.applications.blockchain;

import java.net.Socket;
import java.net.InetAddress;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.security.PrivateKey;
import java.security.PublicKey;

public class PeerIncomingConnection implements Runnable
{
	private Wallet wallet;
	private Socket socket;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	private boolean forever = true;
	private PublicKey peerClient;
	private String peerName;
	private WalletMessageTaskManager messageManager;
	private PeerServer server;
	private boolean blockchainSent = false;
	public PeerIncomingConnection(Wallet wallet, Socket socket, 
			WalletMessageTaskManager messageManager, PeerServer server) throws Exception
	{
		this.wallet = wallet;
		this.messageManager = messageManager;
		this.server = server;
		this.socket = socket;
		this.out = new ObjectOutputStream(this.socket.getOutputStream());
		this.in = new ObjectInputStream(this.socket.getInputStream());
		// sends a MessageID 
		MessageID mid = new MessageID(this.wallet.getPrivateKey(),this.wallet.getPublicKey(), this.wallet.getName());
		this.out.writeObject(mid);
		MessageID md = (MessageID)this.in.readObject();
		this.peerClient = md.getSenderKey();
		this.peerName = md.getName();
		messageManager.addMessageIntoQueue(md);
	}
	
	
	public void run()
	{
		while(forever){
			try{
				Thread.sleep(Configuration.threadSleepTimeMedium());
			}catch(InterruptedException ie){
				LogManager.log(Configuration.logMin(), "Exception in PeerIncomingConnection.run()-1["+ie.getMessage()); 
				activeClose();
			}
			try{
				Message m = (Message)this.in.readObject();
				LogManager.log(Configuration.logMin(),"got a message in IncomingConnection:"+m.getMessageType()+"|"+m.getMessageBody());
				if(m.getMessageType() == Message.TEXT_PRIVATE_CLOSE_CONNECTION){
					//making sure that it is from the correct sender
					MessageTextCloseConnectionPrivate mp = (MessageTextCloseConnectionPrivate)m;
					if(mp.getSenderKey().equals(this.peerClient) 
							&& mp.getReceiver().equals(this.wallet.getPublicKey())){
						LogManager.log(Configuration.logMax(),"The incomingConnection from "+ getConnectionIP() +" is requested to be terminated.");
						server.removePeerConnection(this.peerClient);
						this.close();
					}
				}else if(m.getMessageType() == Message.BLOCKCHAIN_ASK_BROADCAST 
						&& m.getSenderKey().equals(this.peerClient) && !this.blockchainSent){
						MessageAskForBlockchainBroadcast mabcb = (MessageAskForBlockchainBroadcast)m; 
						PublicKey receiver = mabcb.getSenderKey();
						Blockchain bc = this.wallet.getLocalLedger().copy_NotDeepCopy();
						MessageBlockchainPrivate message = new MessageBlockchainPrivate(bc, 	
									wallet.getPublicKey(), receiver);
						//directly sends it back as this is emergency
						this.out.writeObject(message);
				}else{
					this.messageManager.addMessageIntoQueue(m);
				}
			}catch(Exception ioe){
				LogManager.log(Configuration.logMin(), "Exception in PeerIncomingConnection.run()-2["+ioe.getMessage()); 
				this.close();
			}
		}
	}
	
	protected synchronized void activeClose()
	{
		MessageTextCloseConnectionPrivate mc = new MessageTextCloseConnectionPrivate(this.wallet.getPrivateKey(),
				this.wallet.getPublicKey(), this.wallet.getName(), this.peerClient);
		try{
			this.out.writeObject(mc);
			Thread.sleep(Configuration.threadSleepTimeShort());
		}catch(Exception ee){
			LogManager.log(Configuration.logMin(), "Exception in PeerIncomingConnection.activeClose()["+ee.getMessage()); 
		}
		this.close();
		
	}
	
	private synchronized void close()
	{
		this.forever = false;
		try{
			this.in.close();
			this.out.close();
		}catch(Exception e){
			LogManager.log(Configuration.logMin(), "Exception in PeerIncomingConnection.close()["+e.getMessage()); 
		}
		server.removePeerConnection(this.peerClient);
		LogManager.log(Configuration.logMin(), "incoming connection from " + this.getConnectionIP() +" closed");
	} 
	
	public String getConnectionIP(){
		return this.socket.getInetAddress().getHostAddress();
	}
	
	public PublicKey getPeerConnectionKey(){
		return this.peerClient;
	}
}
