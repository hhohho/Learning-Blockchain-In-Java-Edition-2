package mdsky.applications.blockchain;

import java.security.PublicKey;
import java.util.ArrayList;

public class MessageAddressBroadcastAsk extends Message
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private PublicKey sender;
	private String name;
	private String uniqueHashID;
	private long timeStamp = 0;
	public MessageAddressBroadcastAsk(PublicKey sender, String name)
	{
		this.sender = sender;
		this.name = name;
		this.timeStamp = UtilityMethods.getTimeStamp();
		String v = UtilityMethods.getKeyString(sender)+this.timeStamp+UtilityMethods.getUniqueNumber();
		this.uniqueHashID = UtilityMethods.messageDigestSHA256_toString(v+name);
	}
	
	public String getMessageBody(){
		return "Ask for peer information";
	}
	
	public int getMessageType(){
		return Message.ADDRESS_ASK_BROADCAST;
	}
	
	public PublicKey getSenderKey()
	{
		return this.sender;
	}
	
	public boolean isForBroadcast(){
		return true;
	}
	
	public String getName(){
		return this.name;
	}
	
	public KeyNamePair getKeyNamePair(){
		KeyNamePair kp = new KeyNamePair(this.getSenderKey(), this.getName());
		return kp;
	}
	
	public String getMessageHashID(){
		return this.uniqueHashID;
	}
	
	public long getTimeStamp(){
		return this.timeStamp;
	}
	
}
