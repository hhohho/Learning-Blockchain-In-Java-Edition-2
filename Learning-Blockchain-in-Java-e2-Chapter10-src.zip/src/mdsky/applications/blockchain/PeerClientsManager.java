package mdsky.applications.blockchain;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.Enumeration;

public class PeerClientsManager implements Runnable
{
	// The wallet that this manager is working for.
	private Wallet wallet;
    private Hashtable<String, KeyNamePair> allAddresses = new Hashtable<String, KeyNamePair>();
	private boolean forever = true;
	private WalletMessageTaskManager messageManager;
	private Hashtable<String, PeerClient> outgoingConnections = new Hashtable<String, PeerClient>();
	private int autoMakingFriends = 0;
	/**
	 * Both the key and value are IP address
	 */
	//private Hashtable<String, String> failedCreationAttempts = new Hashtable<String, String>();
	private int idleTimes = 0;
	
	public PeerClientsManager(Wallet wallet, WalletMessageTaskManager messageManager)
	{
		this.wallet = wallet;
		this.messageManager = messageManager;
	}
	
	protected void setWalletMessageTaskManager(WalletMessageTaskManager messageManager)
	{
		this.messageManager = messageManager;
	}
	
	public void run()
	{
		while(forever){
			try{
				Thread.sleep(Configuration.threadSleepTimeLong());
			}catch(InterruptedException ie){
				LogManager.log(Configuration.logMin(), "Exception in PeerClientsManager.run()-1["+ie.getMessage());
			}
			
			if((idleTimes+2) %10 == 0 && autoMakingFriends < 3){
				makingFriends();
				autoMakingFriends++;
			}
			
			if(idleTimes > 500){
				idleTimes = 0;
				makingFriends();
			}
			
			try{
				Thread.sleep(Configuration.threadSleepTimeLong());
				idleTimes++;
			}catch(InterruptedException ie){
				LogManager.log(Configuration.logMin(), "Exception in PeerClientsManager.run()-2["+ie.getMessage());
			}
		}
	}
	
	
	
	protected void makingFriends()
	{
		if(PeerServer.getServerIP() != null){
			MessageBroadcastMakingFriend mf = new MessageBroadcastMakingFriend(this.wallet.getPrivateKey(),
				this.wallet.getPublicKey(), this.wallet.getName(), PeerServer.getServerIP());
			//LogManager.log(Configuration.logMin(), "sending messages to make new friends if available.");
			this.sendMessageByAll(mf);
		}
	}
	
	/**
	 * Based on the peer server IP, creates a PeerClient if there is no such one
	 * @param peerServerIP
	 * @return
	 */
	protected synchronized boolean createPeerClient(String peerServerIP)
	{
		try{
			PeerClient client = outgoingConnections.get(peerServerIP);
			//String failedIP = this.failedCreationAttempts.get(peerServerIP);
			if(client == null){// && failedIP == null){
				client = new PeerClient(peerServerIP, Configuration.networkPort(), this.wallet, this);
				/*
				Thread t = new Thread(client);
				t.start();
				*/
				// Add this peer client into the outgoingConnections
				outgoingConnections.put(UtilityMethods.getKeyString(client.getPeerServerPublicKey()), client);
				outgoingConnections.put(peerServerIP, client);
				this.addAddress(client.getPeerServerKeyNamePair());
				LogManager.log(Configuration.logMax(), "created an outgoing connection to " + peerServerIP);
				return true;
			}
		}catch(Exception e){
			LogManager.log(Configuration.logMax(), "Exception in PeerClientsManager.createPeerClient|"
					+peerServerIP+"["+e.getMessage());
			//this.failedCreationAttempts.put(peerServerIP, peerServerIP);
			return false;
		}
		return false;
	}
	
	
	protected void recreatePeerClient(PeerClient peerClient)
	{
		this.removePeerClient(peerClient);
		peerClient.close();
		LogManager.log(Configuration.logMin(), "Recreating peerClient " 
				+ peerClient.getPeerServerName() + "=" + peerClient.getPeerServerIP());
		boolean b = createPeerClient(peerClient.getPeerServerIP());
		if(b){
			LogManager.log(Configuration.logMedium(), "Successfully recreated peerClient "
					+ peerClient.getPeerServerName() + "=" + peerClient.getPeerServerIP());
		}else{
			LogManager.log(Configuration.logMedium(), "Fail to recreate peerClient "
					+ peerClient.getPeerServerName() + "=" + peerClient.getPeerServerIP());
		}
	}
	
	
	protected synchronized void removePeerClient(PeerClient client)
	{
		outgoingConnections.remove(client.getPeerServerIP());
		outgoingConnections.remove(UtilityMethods.getKeyString(client.getPeerServerPublicKey()));
	}
	
	
	/**
	 * This message will be sent by all PeerClient
	 * @param m
	 */
	protected synchronized void sendMessageByAll(Message m)
	{
		Enumeration<PeerClient> E = outgoingConnections.elements();
		while(E.hasMoreElements()){
			PeerClient p = E.nextElement();
			p.sendMessage(m);
		}
	}
	
	/**
	 * Based on the peer's name. If the peer is not inside the stored list,
	 * the message cannot be sent.
	 * @param name
	 * @param m
	 * @return
	 */
	protected synchronized boolean sendMessageByName(String name, Message m)
	{
		ArrayList<KeyNamePair> names = new ArrayList<KeyNamePair>();
		Enumeration<KeyNamePair> E = this.allAddresses.elements();
		while(E.hasMoreElements()){
			KeyNamePair k = E.nextElement();
			if(k.getName().equalsIgnoreCase(name)){
				names.add(k);
			}
		}
		if(names.isEmpty()){
			return false;
		}
		boolean sent = false;
		for(int i=0; i<names.size(); i++){
			String v = UtilityMethods.getKeyString(names.get(i).getKey());
			PeerClient p = outgoingConnections.get(v);
			if(p != null){
				p.sendMessage(m);
				sent = true;
			}
		}
		return sent;
	}
	
	protected synchronized boolean sendMessageByKey(PublicKey key, Message m)
	{
		String v = UtilityMethods.getKeyString(key);
		PeerClient p = outgoingConnections.get(v);
		if(p != null){
			p.sendMessage(m);
			return true;
		}
		return false;
	}
	
	
	public ArrayList<KeyNamePair> getAllStoredAddresses()
	{
		Iterator<KeyNamePair> E = this.allAddresses.values().iterator();
		ArrayList<KeyNamePair> A = new ArrayList<KeyNamePair>();
		while(E.hasNext()){
			A.add(E.next());
		}
		return A;
	}
	
	public void addAddress(KeyNamePair address){
		this.allAddresses.put(UtilityMethods.getKeyString(address.getKey()), address);
	}
	
	/**
	 * This method tells if the public key exists in the name-key pairs.
	 * Note: this method does not examine if a connection to the given public key exists.
	 * Generally speaking, if a connection to the given publick key exists, then this
	 * public key must also exist inside the name-key pairs
	 * @param pk
	 * @return
	 */
	public boolean isExistingUserByPK(PublicKey pk){
		return this.allAddresses.containsKey(UtilityMethods.getKeyString(pk));
	}
	
	public String getNameFromAddress(PublicKey key)
	{
		//if the key is self, then return the wallet's name
		if(key.equals(this.wallet.getPublicKey())){
			return this.wallet.getName();
		}
		String address = UtilityMethods.getKeyString(key);
		KeyNamePair kp = this.allAddresses.get(address);
		if(kp != null){
			return kp.getName();
		}else{
			return address;
		}
	}
	
	public KeyNamePair findKeyNamePair(PublicKey pk)
	{
		return this.allAddresses.get(UtilityMethods.getKeyString(pk));
	}
	
	protected synchronized void closeAllPeerClientsActively()
	{
		LogManager.log(Configuration.logMax(), "PeerClientsManager is closing all client connections");
		Enumeration<PeerClient> E = outgoingConnections.elements();
		while(E.hasMoreElements()){
			PeerClient pc = E.nextElement();
			pc.activeClose();
			this.removePeerClient(pc);
		}
	}
	
	public boolean hasOutgoingConnection(PublicKey key)
	{
		PeerClient pc = outgoingConnections.get(UtilityMethods.getKeyString(key));
		return pc != null;
	}
	
	/**
	 * It becomes complicated here:  in a p2p environment, a transaction T might be sent to the
	 * receiver through multiple channels and may arrive at the receiver multiple times.
	 * So, every message must have a uniqueID: a hashID based on the sender, a unique number at the 
	 * sender side, and probably other information. The receiver must 1) store messages received in 
	 * the past several days (not too old); 2) examine if this message has been received before, if yes,
	 * discard it; 3) clean its message storage time to time to save space and increase efficiency.
	 * This is extremely important to a Transaction.
	 * @param receiver
	 * @param fundToTransfer
	 * @return
	 */
	protected boolean sendTransaction(PublicKey receiver, double fundToTransfer)
	{
		Transaction T = this.wallet.transferFund(receiver, fundToTransfer);
		if(T != null && T.verifySignature()){
			MessageTransactionBroadcast m = new MessageTransactionBroadcast(T);
			this.sendMessageByAll(m);
			return true;
		}
		return false;
	}
	
	protected boolean sendPrivateMessage(PublicKey receiver, String text)
	{
		MessageTextPrivate m = new MessageTextPrivate(text, 
				this.wallet.getPrivateKey(), this.wallet.getPublicKey(),
				this.wallet.getName(), receiver);
		if(!this.sendMessageByKey(receiver, m)){
			this.sendMessageByAll(m);
		}
		return true;
	}
	
	protected void broadcastRequestForBlockchainUpdate()
	{
		MessageAskForBlockchainBroadcast m = new MessageAskForBlockchainBroadcast(
				"update blockchain", wallet.getPrivateKey(), wallet.getPublicKey(), wallet.getName());
		LogManager.log(Configuration.logMin(), "sending message for updating local blockchain of "+this.wallet.getName());
		this.sendMessageByAll(m);
	}
}
