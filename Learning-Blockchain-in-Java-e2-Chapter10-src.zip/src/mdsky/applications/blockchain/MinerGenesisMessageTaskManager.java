package mdsky.applications.blockchain;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

public final class MinerGenesisMessageTaskManager extends MinerMessageTaskManager implements Runnable
{
	private int blocksMined = 0;
	private HashMap<String, KeyNamePair> users = new HashMap<String, KeyNamePair>();
	private PeerClientsManager clientsManager;
	private final int signInBonus = 1000;
	private ArrayList<KeyNamePair> waitingListForSignInBonus = new ArrayList<KeyNamePair>();
	private Miner miner;
	private int idleTimes = 0;

	public MinerGenesisMessageTaskManager(Miner miner, PeerClientsManager clientsManager)
	{
		super(miner, clientsManager);
		this.clientsManager = clientsManager;
		this.miner = miner;
	}
	
	
	/**
	 * The genesis miner will poll the message service provider for new users time to time
	 */
	public void whatToDo()
	{
		try{
			Thread.sleep(Configuration.threadSleepTimeMedium());
			if(waitingListForSignInBonus.size() == 0 && users.size() < Configuration.genesisMiner_signInBonusUsersLimit()){
				this.idleTimes++;
				//send a message out to find new users
				if(this.idleTimes >= 100){
					this.idleTimes = 0;
					MessageAddressBroadcastAsk m = new MessageAddressBroadcastAsk(miner.getPublicKey(), miner.getName());
					this.clientsManager.sendMessageByAll(m);
				}
			}else if(users.size() < Configuration.genesisMiner_signInBonusUsersLimit() && waitingListForSignInBonus.size()>0){
				sendSignInBonus();
			}
		}catch(Exception e){}
	}
	
	/**
	 * This is special for a MinerGenesisMessageTaskManager. Only the genesis miner would send out sign in bonus.
	 * Note that sign-in block has only 1 transaction inside. Other blocks have at least 2 transactions inside.
	 */
	private void sendSignInBonus()
	{
		if(waitingListForSignInBonus.size() <= 0){
			return;
		}
		
		KeyNamePair pk = waitingListForSignInBonus.remove(0);	
		Transaction T = miner.transferFund(pk.getKey(), signInBonus);
		if(T != null && T.verifySignature()){
			System.out.println(miner.getName()+" is sending "+ pk.getName() +" sign-in bonus of "+signInBonus);
			if(blocksMined < Configuration.genesisMiner_selfBlocksToMineLimit() && this.getMiningAction()){
				blocksMined++;
				this.raiseMiningAction();
				System.out.println(miner.getName()+" is mining the sign-in bonus block for " + pk.getName()+" by himself");
				ArrayList<Transaction> tss = new ArrayList<Transaction>();
				tss.add(T);
				MinerTheWorker worker = new MinerTheWorker(miner, this, this.clientsManager, tss);
				Thread miningThread = new Thread(worker);
				miningThread.start();
			}else{
				//broadcast this transaction
				System.out.println(miner.getName()+" is broadcasting the transaction of sign-in bonus for " + pk.getName());
				MessageTransactionBroadcast mtb = new MessageTransactionBroadcast(T);
				this.clientsManager.sendMessageByAll(mtb);
			}
		}else{
			//got to redo :(  this is impossible to happen
			waitingListForSignInBonus.add(0, pk);
		}
		
	}
	
	/**
	 * Rewrite this method so that the genesis miner can send sign-in bonus to new coming users
	 */
	protected void receiveMessageBroadcastMakingFriend(MessageBroadcastMakingFriend m)
	{
		//forward it first
		this.clientsManager.sendMessageByAll(m);
		this.clientsManager.createPeerClient(m.getIP());
		this.clientsManager.addAddress(m.getKeyNamePair());
		String id = UtilityMethods.getKeyString(m.getSenderKey());
		if(!(m.getSenderKey().equals(miner.getPublicKey())) && !users.containsKey(id)){
			users.put(id, m.getKeyNamePair());
			if(users.size() <= Configuration.genesisMiner_signInBonusUsersLimit()){
				this.waitingListForSignInBonus.add(m.getKeyNamePair());
			}	
		}
	}
	
	/**
	 * To make the system simple:
	 * The genesis miner does not compete in mining. It does not collect any published transaction.
	 */
	protected void receiveMessageTransactionBroadcast(MessageTransactionBroadcast mtb)
	{
		// just forward it 
		this.clientsManager.sendMessageByAll(mtb);
	}
	
	/**
	 * This is how a genesis miner acts when receiving a Block
	 * @param mbb
	 */
	protected boolean receiveMessageBlockBroadcast(MessageBlockBroadcast mbb)
	{
		//forward it first
		this.clientsManager.sendMessageByAll(mbb);
		Block block = mbb.getMessageBody();
		boolean b = miner.verifyGuestBlock(block, miner.getLocalLedger());
		boolean c = false;
		if(b){
			c = this.miner.updateLocalLedger(block);
		}
		if(b && c){
			LogManager.log(Configuration.logMin(),"new block is added to the local blockchain, blockchain size = " 
							+ this.miner.getLocalLedger().size());
			displayWallet_MinerBalance(miner);
		}else{
			LogManager.log(Configuration.logMin(),"new block is rejected");
			//got to check if this block is a sign-in bonus block, if it is, then needs to 
			//re-mine it
			if(block.getCreator().equals(miner.getPublicKey())){
				LogManager.log(Configuration.logMin(),"genesis miner's block is rejected. "
						+ "It must be a sign-in bonus block. Check if this transaction has been published "
						+ "by others.");
				//got to redo :(  this is likely to happen if mining competition becomes tight
				String id = UtilityMethods.getKeyString(block.getTransaction(0).getOuputUTXO(0).getReceiver());
				KeyNamePair pk = users.get(id);
				//Modification in chapter 9: 
				//Make sure that this user exists and this sign-in transaction does not exist in the local blockchain.
				//Why should we examine if the sign-in transaction exists in the local blockchain? Well, 
				/*
				 * if the sign-in transaction has been published by other miners, this sign-in block will always
				 * been rejected by the genesis miner. If we do not check the existence of this transaction,
				 * the genesis miner will run into a loop mining this block until this transaction is 
				 * released to other miners after the genesis miner has mined enough blocks.
				 */
				Transaction T = block.getTransaction(0);
				if(pk != null && !(this.miner.getLocalLedger().isTransactionExist(T))){
					//add at the beginning, do not update miningAction
					//if over limit, let other miners to mine the sign-in bonus for the genesis miner
					waitingListForSignInBonus.add(0, pk);
				}else if(pk == null){
					System.out.println();
					System.out.println("ERROR: an existing user for sign-in bonus is not found. Program error");
					System.out.println();
				}
			}
		}
		return b && c;
	}
	
	
	protected void receiveMessageAddressPrivate(MessageAddressPrivate mp)
	{
		ArrayList<KeyNamePair> all = mp.getMessageBody();
		for(int z=0; z<all.size(); z++){
			KeyNamePair pk = all.get(z);
			this.clientsManager.addAddress(pk);
			String ID = UtilityMethods.getKeyString(pk.getKey());
			if(!pk.getKey().equals(miner.getPublicKey()) && !users.containsKey(ID)){
				users.put(ID, pk);
				if(users.size() <= Configuration.genesisMiner_signInBonusUsersLimit()){
					this.waitingListForSignInBonus.add(pk);
				}	
			}
		}
		
		//forward it
		if(!this.clientsManager.sendMessageByKey(mp.getReceiverKey(),mp)){
			this.clientsManager.sendMessageByAll(mp);
		}
	}
	
	
	/**
	 * This method is only for genesis miner to display its balance.
	 * In fact, it is not necessary to display the genesis miner's balance.
	 * Displaying its balances is only for manually examination purpose.
	 * @param miner
	 */
	public static final void displayWallet_MinerBalance(Wallet miner)
	{
		ArrayList<UTXO> all = new ArrayList<UTXO>();
		ArrayList<UTXO> spent = new ArrayList<UTXO>();
		ArrayList<UTXO> unspent = new ArrayList<UTXO>();
		ArrayList<Transaction> ts = new ArrayList<Transaction>();
		double b = miner.getLocalLedger().findRelatedUTXOs(miner.getPublicKey(), all, spent, unspent, ts);
		System.out.println("{");
		System.out.println("\t"+miner.getName()+": balance="+b+",   local blockchain size="+miner.getLocalLedger().size());
		
		double income = 0;
		
		System.out.println("\tAll UTXOs:");
		for(int i=0; i<all.size(); i++){
			UTXO ux = all.get(i);
			
			System.out.println("\t\t"+ux.getFundTransferred()+"|"+ux.getHashID()
				+"|from="+UtilityMethods.getKeyString(ux.getSender())+"|to="+UtilityMethods.getKeyString(ux.getReceiver()));
			
			income += ux.getFundTransferred();
		}
		System.out.println("\t---- total income = " + income+" ----------");
		
		System.out.println("\tSpent UTXOs:");
		income = 0;
		for(int i=0; i<spent.size(); i++){
			UTXO ux = spent.get(i);
			
			System.out.println("\t\t"+ux.getFundTransferred()+"|"+ux.getHashID()
				+"|from="+UtilityMethods.getKeyString(ux.getSender())+"|to="+UtilityMethods.getKeyString(ux.getReceiver()));
			
			income += ux.getFundTransferred();
		}
		System.out.println("\t---- total spending = " + income+" ----------");
		double tsFee = ts.size() * Transaction.TRANSACTION_FEE;
		if(tsFee > 0){
			System.out.println("\t\tTransaction Fee "+tsFee+" is automatically deducted. Please not include it in the calculation");
		}
		System.out.println("\tUnspent UTXOs:");
		income = 0;		
		for(int i=0; i<unspent.size(); i++){
			UTXO ux = unspent.get(i);
			
			System.out.println("\t\t"+ux.getFundTransferred()+"|"+ux.getHashID()
				+"|from="+UtilityMethods.getKeyString(ux.getSender())+"|to="+UtilityMethods.getKeyString(ux.getReceiver()));
			
			income += ux.getFundTransferred();
		}
		System.out.println("\t---- total unspent = " + income+" ----------");
		
		System.out.println("}");
	}
}
