package mdsky.applications.blockchain;

import java.security.PublicKey;
import java.security.PrivateKey;

public class MessageTextBroadcast extends MessageSigned
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private String info = null;
	private byte[] signature = null;
	private PublicKey sender = null;
	private String name = null;
	private String uniqueHashID;
	private long timeStamp;
	
	public MessageTextBroadcast(String text, PrivateKey key, PublicKey pubkey, String name)
	{
		this.info = text;
		this.signature = UtilityMethods.generateSignature(key, text);
		this.sender = pubkey;
		this.name = name;
		this.timeStamp = UtilityMethods.getTimeStamp();
		String v = UtilityMethods.getKeyString(pubkey)+name+this.timeStamp+UtilityMethods.getUniqueNumber();
		this.uniqueHashID = UtilityMethods.messageDigestSHA256_toString(v);
	}
	
	public String getMessageBody(){
		return this.info;
	}

	public boolean isValid()
	{
		return UtilityMethods.verifySignature(this.sender, this.signature, this.info);
	}
	
	public int getMessageType(){
		return Message.TEXT_BROADCAST;
	}
	
	public boolean isForBroadcast(){
		return true;
	}
	
	public PublicKey getSenderKey(){
		return this.sender;
	}
	
	public String getSenderName(){
		return this.name;
	}
	
	public String getMessageHashID(){
		return this.uniqueHashID;
	}
	
	public long getTimeStamp(){
		return this.timeStamp;
	}
}

