package mdsky.applications.blockchain;

import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.util.Hashtable;
import java.security.PublicKey;
import java.util.Enumeration;

public class PeerServer implements Runnable
{
	// The wallet this peer server is working on behalf of
	private Wallet wallet;
	private ServerSocket server;
	private static String IP = null;
	private boolean forever = true;
	private Hashtable<String, PeerIncomingConnection> connections = new Hashtable<String, PeerIncomingConnection>();
	private WalletMessageTaskManager messageManager;
	private PeerClientsManager clientManager;
	PeerServer(Wallet wallet, WalletMessageTaskManager messageManager, PeerClientsManager clientManager) throws Exception
	{
		this.wallet = wallet;
		this.messageManager = messageManager;
		this.clientManager = clientManager;
		server = new ServerSocket(Configuration.networkPort());
		IP = server.getInetAddress().getLocalHost().getHostAddress();
	}
	
	public static String getServerIP(){
		return IP;
	}
	
	public void run()
	{
		System.out.println("server is listening now");
		while(forever){
			try{
				Socket socket = this.server.accept();
				InetAddress clientAddress = socket.getInetAddress();
				LogManager.log(Configuration.logMax(),"Got an incoming connection request from " + clientAddress.getHostAddress());
				PeerIncomingConnection peer = new PeerIncomingConnection(wallet, socket, messageManager, this);
				Thread t = new Thread(peer);
				t.start();
				LogManager.log(Configuration.logMax(), "PeerIncomingConnection with "+peer.getConnectionIP()+" established");
				//also, try to create a PeerClient connection, too if there is no such one
				this.clientManager.createPeerClient(peer.getConnectionIP());
				LogManager.log(Configuration.logMin(), "creates PeerClient connection with "+peer.getConnectionIP());
				connections.put(UtilityMethods.getKeyString(peer.getPeerConnectionKey()), peer);
			}catch(Exception ioe){
				LogManager.log(Configuration.logMax(), "Exception in PeerServer.run()["+ioe.getMessage()); 
				forever = false;
			}
		}
		shutdownAllConnectionsActively();
		System.exit(0);
	}

	protected synchronized boolean removePeerConnection(PublicKey key)
	{
		PeerIncomingConnection peer = this.connections.remove(UtilityMethods.getKeyString(key));
		return peer != null;
	}
	
	protected synchronized void shutdownPeerIncomingConnection(PublicKey key)
	{
		PeerIncomingConnection peer = this.connections.get(UtilityMethods.getKeyString(key));
		if(peer != null){
			peer.activeClose();
		}
		removePeerConnection(key);
	}

	
	protected synchronized void shutdownAllConnectionsActively()
	{
		LogManager.log(Configuration.logMax(), "PeerServer is requesting to close all incoming connections");
		Enumeration<PeerIncomingConnection> E = this.connections.elements();
		while(E.hasMoreElements()){
			E.nextElement().activeClose();
		}
		this.connections.clear();
	}
	
	/**
	 * 
	 * @param key
	 * @return	0 = no direct connection, 1 = incoming connection from the key only, 2 = outgoing connection to the key
	 * only, 3 = both incoming from and outgoing connection to the key.
	 */
	protected int hasDirectConnection(PublicKey key)
	{
		PeerIncomingConnection peer = this.connections.get(UtilityMethods.getKeyString(key));
		boolean hasClient = this.clientManager.hasOutgoingConnection(key);
		if(peer == null && !hasClient){
			return 0;
		}else if(peer != null && hasClient){
			return 3;
		}else if(peer != null){
			return 1;
		}else{
			return 2;
		}
	}
}
