package mdsky.applications.blockchain;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.Hashtable;
import java.util.Enumeration;

public class WalletMessageTaskManager implements Runnable
{
	private boolean forever = true;
	// The Wallet this task manager is working for
	private Wallet wallet;
	// Stores messages that have been processed. If a message has been processed, 
	// then the arrival of the same message will be ignored.
	private Hashtable<String, Message> existingMessages = new Hashtable<String, Message>();
	//The message queue that stores current message waiting to be sent
	private ConcurrentLinkedQueue<Message> messageQueue = new ConcurrentLinkedQueue<Message>();
	private PeerConnectionManager connectionManager;
	private WalletSimulator simulator = null;
	private int idleTimes = 0;
	
	public WalletMessageTaskManager(Wallet wallet, PeerConnectionManager connectionManager)
	{
		this.wallet = wallet;
		this.connectionManager = connectionManager;
	}
	
	public void setSimulator(WalletSimulator simulator){
		this.simulator = simulator;
	}
	
	/**
	 * The following incoming messages will NOT be added into the queue:
	 * <li> Messages originally sent by this wallet.
	 * <li> Messages that have already been processed before.
	 * <li> Messages that are too old
	 * @param msg
	 */
	public void addMessageIntoQueue(Message msg)
	{
		//check if this message is sent by this wallet
		if(msg.getSenderKey().equals(this.wallet.getPublicKey()) && !msg.selfMessageAllowed()){
			return;
		}
		//check if this message is too old
		if(UtilityMethods.isMessageTooOld(msg.getTimeStamp())){
			return;
		}
		//check if this messsage has been processed before
		Message m = existingMessages.get(msg.getMessageHashID());
		if(m != null){
			return;
		}
		//mark that this message as being processed
		existingMessages.put(msg.getMessageHashID(), msg);
		//this message is valid, add it into the queue
		this.messageQueue.add(msg);
	}
	
	
	public void whatToDo()
	{
		//do nothing
	}
	
	public void run()
	{
		while(forever){
			try{
				//sleep a while to release CPU resource
				Thread.sleep(Configuration.threadSleepTimeMedium());
				idleTimes ++;
			}catch(InterruptedException ee){
				LogManager.log(Configuration.logMin(), "Exception in WalletMessageTaskManager.run()["+ee.getMessage()); 
			}
			
			if(idleTimes >= 400000){
				//let's discard the messages that is too old inside processedMessages
				idleTimes = 0;
				discardObseleteMessages();
			}
			
			if(this.messageQueue.isEmpty()){
				whatToDo();
				try{
					Thread.sleep(Configuration.threadSleepTimeLong());
				}catch(InterruptedException ie){
					LogManager.log(Configuration.logMin(), "Exception in WalletMessageTaskManager.run()-2["+ie.getMessage());
				}
			}else{
				while(!(this.messageQueue.isEmpty())){
					Message m = this.messageQueue.poll();
					processMessage(m);
				}
			}
		}
	}
	
	private synchronized void discardObseleteMessages()
	{
		Enumeration<Message>  E = existingMessages.elements();
		while(E.hasMoreElements()){
			Message m = E.nextElement();
			if(UtilityMethods.isMessageTooOld(m.getTimeStamp())){
				existingMessages.remove(m.getMessageHashID());
			}
		}
	}
	
	
	protected void processMessage(Message message) //throws Exception
	{
    	if(message == null){
    		return;
    	}
		if(!message.isForBroadcast()){
			//this is a private message for this wallet
			//it can be a text message
			if(message.getMessageType() == Message.TEXT_PRIVATE){
				//got to confirm the message
				MessageTextPrivate m = (MessageTextPrivate)message;
				if(!m.isValid()){
					LogManager.log(Configuration.logMax(), "In WalletMessageTaskManager.processMessage()[text private message tampered");
					return;
				}
				receivePrivateChatMessage(m);
			}else if(message.getMessageType() == Message.ADDRESS_PRIVATE){
				MessageAddressPrivate mp = (MessageAddressPrivate)message;
				receiveMessageAddressPrivate(mp);
			}else if(message.getMessageType() == Message.BLOCKCHAIN_PRIVATE){
				MessageBlockchainPrivate mbcb = (MessageBlockchainPrivate)message;
				receiveMessagaeBlockchainPrivate(mbcb);
			}else{
				LogManager.log(Configuration.logMax(), "In WalletMessageTaskManager.processMessage()[....weird private message, not supported, please check ......");
			}
		//now, about those broad messages
		}else if(message.getMessageType() == Message.BLOCK_BROADCAST){
			//when a wallet gets a block, he will validate it and then try to update it
			LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.processMessage()[it is a block broadcast message, check if it is necessary to update it");
			MessageBlockBroadcast mbb = (MessageBlockBroadcast)message;
			this.receiveMessageBlockBroadcast(mbb);
		}else if(message.getMessageType() == Message.BLOCKCHAIN_BROADCAST){
			LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.processMessage()[It is a blockchain broadcast message, check if it is necessary to update the blockchain");
			MessageBlockchainBroadcast mbcb = (MessageBlockchainBroadcast)message;
			//Modification in chapter 9
			boolean b = receiveBlockchainBroadcast(mbcb);
			if(b){
				LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.processMessage()[blockchain is updated!");
			}else{
				LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.processMessage()[rejected the new blockchain");
			}
		}else if(message.getMessageType() == Message.TRANSACTION_BROADCAST){
			//as a wallet does not collect transaction or mine a block, a wallet will just pay attention to the
			//transaction that has payment to herself/himself
			LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.processMessage()[It is a transaction broadcast message");
			MessageTransactionBroadcast mtb = (MessageTransactionBroadcast)message;
			this.receiveMessageTransactionBroadcast(mtb);
		}else if(message.getMessageType() == Message.BLOCKCHAIN_ASK_BROADCAST){
			MessageAskForBlockchainBroadcast mabcb = (MessageAskForBlockchainBroadcast)message;
			if(mabcb.isValid()){
				receiveMessageForBlockchainBroadcast(mabcb);
			}
		}else if(message.getMessageType() == Message.TEXT_BROADCAST){
			MessageTextBroadcast mtb = (MessageTextBroadcast)message;
			receiveMessageTextBroadcast(mtb);
		}else if(message.getMessageType() == Message.ADDRESS_BROADCAST_MAKING_FRIEND){
			receiveMessageBroadcastMakingFriend((MessageBroadcastMakingFriend)message);
		}else if(message.getMessageType() == Message.ADDRESS_ASK_BROADCAST){
			receiveMessageAddressBroadcastAsk((MessageAddressBroadcastAsk)message);
		}
	}
		
	protected void receiveMessageAddressBroadcastAsk(MessageAddressBroadcastAsk m)
	{
		//forward it first
		this.connectionManager.sendMessageByAll(m);
		//prepare such a message and then send it
		KeyNamePair self = new KeyNamePair(this.wallet.getPublicKey(), this.wallet.getName());
		ArrayList<KeyNamePair> pair = this.connectionManager.getAllStoredAddresses();
		pair.add(self);
		MessageAddressPrivate map = new MessageAddressPrivate(pair, 
				this.wallet.getPublicKey(), m.getSenderKey());
		if(!this.connectionManager.sendMessageByKey(m.getSenderKey(), map)){
			this.connectionManager.sendMessageByAll(map);
		}
	}
	
	
	protected void receiveMessageBroadcastMakingFriend(MessageBroadcastMakingFriend m)
	{
		//forward it first
		this.connectionManager.sendMessageByAll(m);
		//try to make a connection
		this.connectionManager.createOutgoingConnection(m.getIP());
	}
	
	protected void receiveMessageTextBroadcast(MessageTextBroadcast mtb)
	{
		//forward it first
		this.connectionManager.sendMessageByAll(mtb);
		//show the message on the message board
		String text = mtb.getMessageBody();
		String name = mtb.getSenderName();
		this.simulator.appendMessageLineOnBoard(name+"]: "+text);
		//Automatically store the user information (can be self)
		this.connectionManager.addAddress(new KeyNamePair(mtb.getSenderKey(), mtb.getSenderName()));
	}
	
	protected void receiveMessageAddressPrivate(MessageAddressPrivate mp)
	{
		if(mp.getReceiverKey().equals(this.wallet.getPublicKey())){
			ArrayList<KeyNamePair> all = mp.getMessageBody();
			LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.receiveMessageAddressPrivate()[There are these many addresses (users) available (in addition to yourself): ");
			for(int z=0; z<all.size(); z++){
				KeyNamePair pk = all.get(z);
				if(!pk.getKey().equals(wallet.getPublicKey())){
					connectionManager.addAddress(pk);
					LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.receiveMessageAddressPrivate()["+pk.getName()+"| key="+UtilityMethods.getKeyString(pk.getKey()));
				}
			}
		}else{
			//forward it
			if(!this.connectionManager.sendMessageByKey(mp.getReceiverKey(),mp)){
				this.connectionManager.sendMessageByAll(mp);
			}
		}
	}
	
	protected void receivePrivateChatMessage(MessageTextPrivate m)
	{
		//check if this chat message is really for me. If not, need to relay it
		if(!(m.getReceiver().equals(this.wallet.getPublicKey()))){
			boolean done = this.connectionManager.sendMessageByKey(m.getReceiver(), m);
			if(!done){
				// The message recipient is not directly connected. Got to relay
				this.connectionManager.sendMessageByAll(m);
			}
		}else{
			String text = m.getMessageBody();
			String name = m.getSenderName();
			this.simulator.appendMessageLineOnBoard("private<--"+name+"]: "+text);
			//Automatically store the user information
			connectionManager.addAddress(new KeyNamePair(m.getSenderKey(), m.getSenderName()));
		}
	}
	
	
	/**
	 * For a wallet, it ignore such a message
	 * @param mabcb
	 */
	protected void receiveMessageForBlockchainBroadcast(MessageAskForBlockchainBroadcast mabcb)
	{
		LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.receiveQueryForBlockchainBroadcast()[I am just a wallet, I can only forward the request for blockchain.");
		this.connectionManager.sendMessageByAll(mabcb);
	}
	
	/**
	 * Modification in chapter 9: added
	 * @param mbcb
	 * @return
	 */
	protected boolean receiveBlockchainBroadcast(MessageBlockchainBroadcast mbcb)
	{
		//in P2P environment, we need to forward the message first
		this.connectionManager.sendMessageByAll(mbcb);
		return this.wallet.setLocalLedger(mbcb.getMessageBody());
	}
	
	
	/**
	 * This is the version for Wallet only. The wallet can either ignore it or 
	 * send a THNAK YOU message to the transaction publisher.
	 * @param mtb
	 */
	protected void receiveMessageTransactionBroadcast(MessageTransactionBroadcast mtb)
	{
		//forward it first
		this.connectionManager.sendMessageByAll(mtb);
		//examine if there is anything to this wallet
		Transaction ts = mtb.getMessageBody();
		if(ts.getSender().equals(this.wallet.getPublicKey())){
			return;
		}
		int n = ts.getNumberOfOutputUTXOs();
		int total = 0;
		for(int i=0; i<n; i++){
			UTXO ut = ts.getOuputUTXO(i);
			if(ut.getReceiver().equals(this.wallet.getPublicKey())){
				total += ut.getFundTransferred();
			}
		}
		//if the UTXO sender is self, do not display this message
		if(total > 0){
			LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.receiveMessageTransactionBroadcast()"
						+"[in the transaction, there is payment of " + total+" to me. Sending THANK YOU to the payer");
			MessageTextPrivate mtp = new MessageTextPrivate("Thank you for the fund of "+total+", waiting for its publishing.",
					this.wallet.getPrivateKey(), this.wallet.getPublicKey(), this.wallet.getName(), ts.getSender());
			this.connectionManager.sendMessageByKey(mtb.getSenderKey(), mtp);
		}
		
	}
	
	protected boolean receiveMessageBlockBroadcast(MessageBlockBroadcast mbb)
	{
		//Different from the client-server model, in a P2P environment, we need
		//to forward the message first
		this.connectionManager.sendMessageByAll(mbb);
		//now update local blockchain
		Block block = mbb.getMessageBody();
		boolean b = this.wallet.updateLocalLedger(block);
		if(b){
			LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.receiveMessageBlockBroadcast()"
					+ "[new block is added to the local blockchain");
		}else{
			int size = block.getTotalNumberOfTransactions();
			int counter = 0;
			for(int i=0; i<size; i++){
				Transaction T = block.getTransaction(i);
				if(!this.wallet.getLocalLedger().isTransactionExist(T)){
					MessageTransactionBroadcast mt = new MessageTransactionBroadcast(T);
					this.connectionManager.sendMessageByAll(mt);
					counter++;
				}
			}
			LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.receiveMessageBlockBroadcast()["
					+"new block is rejected, released "+ counter+" unpublished transactions into the pool");
		}
		return b;
	}
	
	protected void receiveMessagaeBlockchainPrivate(MessageBlockchainPrivate mbcb)
	{
		LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.receiveMessagaeBlockchainPrivate()["
				+"It is a blockchain private message, check if it is for me and if necessary to update the blockchain");
		if(mbcb.getReceiver().equals(this.wallet.getPublicKey())){
			boolean b = this.wallet.setLocalLedger(mbcb.getMessageBody());
			if(b){
				LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.receiveMessagaeBlockchainPrivate()[blockchain is updated!");
			}else{
				LogManager.log(Configuration.logMin(), "In WalletMessageTaskManager.receiveMessagaeBlockchainPrivate()[rejected the new blockchain");
			}
		}else{
			//forward it
			if(!this.connectionManager.sendMessageByKey(mbcb.getReceiver(), mbcb)){
				this.connectionManager.sendMessageByAll(mbcb);
			}
		}
	}
	
	
	protected void close()
	{
		forever = false;
	}
	
	
}
