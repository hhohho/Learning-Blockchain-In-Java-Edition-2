package mdsky.applications.blockchain;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.security.PublicKey;

/**
 * A PeerOutgoingConnection is a TCP socket connection in which this peer is a client socket.
 * Both pipes of the TCP connection are used for communication.
 * @author hzhou
 *
 */
public class PeerOutgoingConnection implements Runnable
{
	private Wallet wallet;
	private Socket socket;
	//The IP address of the server socket that this outgoing connection is connected to
	private String connectionIP;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	//the public key of the peer that this outgoing connection is connected to 
	private PublicKey connectionPeerPubkey;
	//the name of the peer that this outgoing connection is connected to 
	private String connectionPeerName;
	private boolean forever = true;
	private PeerConnectionManager connectionManager;
	private WalletMessageTaskManager messageManager;
	
	protected PeerOutgoingConnection(String serverIP, Wallet wallet, 
			WalletMessageTaskManager messageManager, PeerConnectionManager connectionManager) throws Exception
	{
		this.wallet = wallet;
		this.messageManager = messageManager;
		this.connectionManager = connectionManager;
		LogManager.log(Configuration.logMax(), wallet.getName()+" is creating a peer outgoing connection to " + serverIP);
		this.connectionIP = serverIP;
        socket = new Socket(serverIP, Configuration.networkPort());
        out = new ObjectOutputStream(socket.getOutputStream());
        in = new ObjectInputStream(socket.getInputStream());
        //the peer client will get a MessageForID from the peer server
        MessageID fromPeerServer = (MessageID)in.readObject();
        //make sure that the message is in good standing
        if(fromPeerServer.isValid()){
        	this.connectionPeerPubkey = fromPeerServer.getSenderKey();
        	this.connectionPeerName = fromPeerServer.getName();
        }else{
        	throw new Exception("MessageID from peer server is invalid.");
        }
        //if everything works well, the agent sends the server a responding MessageForID
        //because the server is waiting for the client to send in a MessageForID
        LogManager.log(Configuration.logMax(), "obtained peer server address and stored it, now sending wallet public key to peer server");
        LogManager.log(Configuration.logMax(), "name="+this.wallet.getName());
        MessageID mid = new MessageID(this.wallet.getPrivateKey(), this.wallet.getPublicKey(), this.wallet.getName());
        out.writeObject(mid);
        LogManager.log(Configuration.logMax(), "A peer client outgoingconnection to " + this.connectionIP + " is established successfully.");
        if(this.wallet.getLocalLedger() == null){
        	//directly asks for a blockchain before doing anything
        	MessageAskForBlockchainPrivate m = new MessageAskForBlockchainPrivate("update blockchain",
        			wallet.getPrivateKey(), wallet.getPublicKey(), wallet.getName(), this.connectionPeerPubkey, true);
        	
        	out.writeObject(m);
        	//wait for such a response
        	MessageBlockchainPrivate mbcb = (MessageBlockchainPrivate)in.readObject();
        	LogManager.log(Configuration.logMin(), "In PeerOutgoingConnection.constructor["
        				+"It is a blockchain private message, check if it is for me and if necessary to update the blockchain");
        	boolean b = this.wallet.setLocalLedger(mbcb.getMessageBody());
        	if(b){
        		LogManager.log(Configuration.logMax(), "blockchain updated successfully");
        	}else{
        		LogManager.log(Configuration.logMax(), "In PeerOutgoingConnection.constructor["
        				+ "blockchain update failed for " + this.wallet.getName()+" from "+ this.getConnectionIP());
        		throw new RuntimeException("In In PeerOutgoingConnection.constructor["
        				+ "blockchain update failed for " + this.wallet.getName()+" from "+ this.getConnectionIP());
        	}
        }else{
    		MessageAskForBlockchainPrivate m = new MessageAskForBlockchainPrivate("update blockchain",
        			wallet.getPrivateKey(), wallet.getPublicKey(), wallet.getName(), this.connectionPeerPubkey, false);
        	
        	out.writeObject(m);
    	}
        this.connectionManager.addAddress(fromPeerServer.getKeyNamePair());
	}
	
	public synchronized boolean sendMessage(Message m)
	{
		//double ensure that all null message is not sent
		if(m == null){
			LogManager.log(Configuration.logMin(), "message is null, cannot send");
			return false;
		}
		try{
			this.out.writeObject(m);
			return true;
		}catch(Exception e){
			LogManager.log(Configuration.logMax(), 
					"Exception in PeerOutgoingConnection.sendMessage()|" + this.getConnectionIP()
					+ "|failed to send message [" + e.getMessage());
			//need to recreate this connection for at least one time
			if(!this.connectionManager.recreatePeerOutgoingConnection(this)){
				//recreation failed, then close
				this.close();
			}
			return false;
		}
	}
	
	/**
	 * Obtain the public key of the peer on another end of the connection
	 * @return
	 */
	public PublicKey getConnectionPeerPublicKey(){
		return this.connectionPeerPubkey;
	}
	
	/**
	 * Obtain the name of the peer on another end of the connection
	 * @return
	 */
	public String getConnectionPeerName(){
		return this.connectionPeerName;
	}
	
	/**
	 * Obtain the KeyNamePair of the peer on another end of the connection
	 * @return
	 */
	public KeyNamePair getConnectionPeerNamePair(){
		return new KeyNamePair(this.connectionPeerPubkey, this.connectionPeerName);
	}
	
	/**
	 * Obtain the IP of the peer on another end of the connection
	 * @return
	 */
	public String getConnectionIP(){
		return this.connectionIP;
	}
	
	/**
	 * A close action initiated by the peer owning this connection, i.e, the close action
	 * is initiated on this end of the connection. Such an action requires a connection-close-message
	 * to be sent to another end of the connection.
	 */
	protected void activeClose()
	{
		MessageTextCloseConnectionPrivate mc = new MessageTextCloseConnectionPrivate(this.wallet.getPrivateKey(),
				this.wallet.getPublicKey(), this.wallet.getName(), this.getConnectionPeerPublicKey());
		this.sendMessage(mc);
		try{
			Thread.sleep(Configuration.threadSleepTimeShort());
		}catch(Exception ee){
			LogManager.log(Configuration.logMax(), "Exception in PeerOutgoingConnection.activeClose()|"
					+ this.getConnectionIP() + "[" + ee.getMessage());
		}
		this.close();
	}
	
	/**
	 * Close the input and output stream of the connection.
	 */
	private void close()
	{
		this.forever = false;
		try{
			this.in.close();
			this.out.close();
		}catch(Exception e){
			
		}
		this.connectionManager.removePeerConnection(this);
		LogManager.log(Configuration.logMax(), "Peer outgoing connection to " 
				+ this.connectionIP +"/" + this.getConnectionPeerName() + " is terminated.");
	} 
	
	
	public void run()
	{
		while(forever){
			try{
				Thread.sleep(Configuration.threadSleepTimeMedium());
				//Still accepting messages from the peer-server.
				//If the message to close the connection is from the peer server, 
				//this peer connection should terminate.
				Message m = (Message)in.readObject();
				LogManager.log(Configuration.logMin(), "got a message in outgoingConnection:"+m.getMessageType()
						+"|from "+this.connectionIP+"/"+this.connectionPeerName+"|"+m.getMessageBody());
				if(m.getMessageType() == Message.TEXT_PRIVATE_CLOSE_CONNECTION){
					MessageTextCloseConnectionPrivate mp = (MessageTextCloseConnectionPrivate)m;
					if(mp.getSenderKey().equals(this.getConnectionPeerPublicKey()) 
							&& mp.getReceiver().equals(this.wallet.getPublicKey())){
						this.close();
						LogManager.log(Configuration.logMax(), this.getConnectionIP() + "/" + this.getConnectionPeerName()
							+" initiates connection close, the peer outgoing connection is closing now.");
					}
				}else{
					this.messageManager.addMessageIntoQueue(m);
				}
			}catch(Exception e){
				LogManager.log(Configuration.logMax(), "Exception In PeerOutgoingConnection.run()|"
						+ this.getConnectionIP() + "/" + this.getConnectionPeerName() + "[ "+e.getMessage());
				this.close();
			}
		}
	}
}
