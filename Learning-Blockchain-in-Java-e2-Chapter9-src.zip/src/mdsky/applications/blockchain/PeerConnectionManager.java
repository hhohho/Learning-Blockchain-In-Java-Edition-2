package mdsky.applications.blockchain;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Enumeration;

public class PeerConnectionManager implements Runnable
{
	// The wallet that this manager is working for.
	private Wallet wallet;
    private Hashtable<String, KeyNamePair> allAddresses = new Hashtable<String, KeyNamePair>();
	private boolean forever = true;
	private WalletMessageTaskManager messageManager;
	private Hashtable<String, PeerOutgoingConnection> outgoingConnections = new Hashtable<String, PeerOutgoingConnection>();
	private Hashtable<String, PeerIncomingConnection> incomingConnections = new Hashtable<String, PeerIncomingConnection>();
	private int autoMakingFriends = 0;
	private int idleTimes = 0;
	
	public PeerConnectionManager(Wallet wallet, WalletMessageTaskManager messageManager)
	{
		this.wallet = wallet;
		this.messageManager = messageManager;
	}
	
	protected void setWalletMessageTaskManager(WalletMessageTaskManager messageManager)
	{
		this.messageManager = messageManager;
	}
	
	public void run()
	{
		while(forever){
			try{
				Thread.sleep(Configuration.threadSleepTimeLong());
			}catch(InterruptedException ie){
				LogManager.log(Configuration.logMin(), "Exception in PeerConnectionManager.run()-1["+ie.getMessage());
			}
			
			if((idleTimes+2) %10 == 0 && autoMakingFriends < 3){
				makingFriends();
				autoMakingFriends++;
			}
			
			try{
				Thread.sleep(Configuration.threadSleepTimeLong());
				idleTimes++;
			}catch(InterruptedException ie){
				LogManager.log(Configuration.logMin(), "Exception in PeerConnectionManager.run()-2["+ie.getMessage());
			}
			
			if(idleTimes % 100 == 0){
				idleTimes = 0;
			}
		}
	}
	
	
	
	
	protected void makingFriends()
	{
		if(PeerServer.getServerIP() != null && this.numberOfExistingIncomingConnections() < Configuration.incomingConnectionsLimit()){
			MessageBroadcastMakingFriend mf = new MessageBroadcastMakingFriend(this.wallet.getPrivateKey(),
				this.wallet.getPublicKey(), this.wallet.getName(), PeerServer.getServerIP());
			//LogManager.log(Configuration.logMin(), "sending messages to make new friends if available.");
			this.sendMessageByAll(mf);
		}
	}
	
	/**
	 * Based on the IP address of the peer that acts like a server, creates a PeerOutgoingConnection if there is no such one
	 * @param peerServerIP the IP address of the peer that acts like a server
	 * @return
	 */
	protected synchronized boolean createOutgoingConnection(String peerServerIP)
	{
		if(this.outgoingConnections.size() >= Configuration.outGoingConnectionsLimit()){
			LogManager.log(Configuration.logMax(), "cannot create the outgoing connection to " 
					+ peerServerIP + " because the current size of " + this.outgoingConnections.size() 
					+" has already reached the limit of " + Configuration.outGoingConnectionsLimit());
			return false;
		}
		
		PeerIncomingConnection pi = this.incomingConnections.get(peerServerIP);
		if(pi != null){
			LogManager.log(Configuration.logMin(), "cannot create the outgoing connection to "
					+ peerServerIP +" because there is already an incoming connection from "
					+ pi.getConnectionIP() + "/" + pi.getConnectionPeerName());
			return false;
		}
		
		try{
			PeerOutgoingConnection client = outgoingConnections.get(peerServerIP);
			if(client == null){
				client = new PeerOutgoingConnection(peerServerIP, this.wallet, this.messageManager, this);
				Thread t = new Thread(client);
				t.start();
				// Add this peer client into the outgoingConnections
				outgoingConnections.put(UtilityMethods.getKeyString(client.getConnectionPeerPublicKey()), client);
				outgoingConnections.put(peerServerIP, client);
				this.addAddress(client.getConnectionPeerNamePair());
				LogManager.log(Configuration.logMax(), "created an outgoing connection to " + peerServerIP);
				return true;
			}
		}catch(Exception e){
			LogManager.log(Configuration.logMax(), "Exception in PeerConnectionManager.createOutgoingConnection|"
					+peerServerIP+"["+e.getMessage());
			//this.failedCreationAttempts.put(peerServerIP, peerServerIP);
			//e.printStackTrace();
			return false;
		}
		return false;
	}
	
	protected boolean recreatePeerOutgoingConnection(PeerOutgoingConnection con)
	{
		this.removePeerConnection(con);
		return createOutgoingConnection(con.getConnectionIP());
	}
	
	
	protected void addIncomingConnection(PeerIncomingConnection con)
	{
		this.incomingConnections.put(UtilityMethods.getKeyString(con.getConnectionPeerPublicKey()), con);
		this.incomingConnections.put(con.getConnectionIP(), con);
	}
	
	protected synchronized void removePeerConnection(PeerOutgoingConnection con)
	{
		outgoingConnections.remove(con.getConnectionIP());
		outgoingConnections.remove(UtilityMethods.getKeyString(con.getConnectionPeerPublicKey()));
	}
	
	protected synchronized void removePeerConnection(PeerIncomingConnection con)
	{
		incomingConnections.remove(con.getConnectionIP());
		incomingConnections.remove(UtilityMethods.getKeyString(con.getConnectionPeerPublicKey()));
	}
	
	
	/**
	 * This message will be sent by all connections, both incoming and outgoing
	 * @param m
	 */
	protected synchronized void sendMessageByAll(Message m)
	{
		Enumeration<PeerOutgoingConnection> E = outgoingConnections.elements();
		while(E.hasMoreElements()){
			PeerOutgoingConnection p = E.nextElement();
			p.sendMessage(m);
		}
		
		Enumeration<PeerIncomingConnection> E2 = incomingConnections.elements();
		while(E2.hasMoreElements()){
			PeerIncomingConnection p = E2.nextElement();
			p.sendMessage(m);
		}
	}
	

	protected synchronized boolean sendMessageByKey(PublicKey key, Message m)
	{
		String v = UtilityMethods.getKeyString(key);
		PeerOutgoingConnection p = outgoingConnections.get(v);
		if(p != null){
			p.sendMessage(m);
			return true;
		}
		//find the connection inside the incomingConnections
		PeerIncomingConnection pi = incomingConnections.get(v);
		if(pi != null){
			pi.sendMessage(m);
			return true;
		}
		return false;
	}
	
	
	public ArrayList<KeyNamePair> getAllStoredAddresses()
	{
		Iterator<KeyNamePair> E = this.allAddresses.values().iterator();
		ArrayList<KeyNamePair> A = new ArrayList<KeyNamePair>();
		while(E.hasNext()){
			A.add(E.next());
		}
		return A;
	}
	
	public void addAddress(KeyNamePair address){
		if(!this.isExistingUserByPK(address.getKey())){
			this.allAddresses.put(UtilityMethods.getKeyString(address.getKey()), address);
		}
	}
	
	/**
	 * This method tells if the public key exists in the name-key pairs.
	 * Note: this method does not examine if a connection to the given public key exists.
	 * Generally speaking, if a connection to the given public key exists, then this
	 * public key must also exist inside the name-key pairs
	 * @param pk
	 * @return
	 */
	public boolean isExistingUserByPK(PublicKey pk){
		return this.allAddresses.containsKey(UtilityMethods.getKeyString(pk));
	}
	
	public String getNameFromAddress(PublicKey key)
	{
		//if the key is self, then return the wallet's name
		if(key.equals(this.wallet.getPublicKey())){
			return this.wallet.getName();
		}
		String address = UtilityMethods.getKeyString(key);
		KeyNamePair kp = this.allAddresses.get(address);
		if(kp != null){
			return kp.getName();
		}else{
			return address;
		}
	}
	
	public KeyNamePair findKeyNamePair(PublicKey pk)
	{
		return this.allAddresses.get(UtilityMethods.getKeyString(pk));
	}
	
	protected synchronized void closeAllPeerConnectionsActively()
	{
		Enumeration<PeerOutgoingConnection> Eo = outgoingConnections.elements();
		while(Eo.hasMoreElements()){
			PeerOutgoingConnection po = Eo.nextElement();
			po.activeClose();
			this.removePeerConnection(po);
		}
		
		Enumeration<PeerIncomingConnection> Ei = incomingConnections.elements();
		while(Ei.hasMoreElements()){
			PeerIncomingConnection pi = Ei.nextElement();
			pi.activeClose();
			this.removePeerConnection(pi);
		}
	}
	
	protected synchronized void shutdownAll()
	{
		closeAllPeerConnectionsActively();
		this.forever = false;
	}
	
	/**
	 * It becomes complicated here:  in a p2p environment, a transaction T might be sent to the
	 * receiver through multiple channels and may arrive at the receiver multiple times.
	 * So, every message must have a uniqueID: a hashID based on the sender, a unique number at the 
	 * sender side, and probably other information. The receiver must 1) store messages received in 
	 * the past several days (not too old); 2) examine if this message has been received before, if yes,
	 * discard it; 3) clean its message storage time to time to save space and increase efficiency.
	 * This is extremely important to a Transaction.
	 * @param receiver
	 * @param fundToTransfer
	 * @return
	 */
	protected boolean sendTransaction(PublicKey receiver, double fundToTransfer)
	{
		Transaction T = this.wallet.transferFund(receiver, fundToTransfer);
		if(T != null && T.verifySignature()){
			MessageTransactionBroadcast m = new MessageTransactionBroadcast(T);
			this.sendMessageByAll(m);
			return true;
		}
		return false;
	}
	
	protected boolean sendPrivateMessage(PublicKey receiver, String text)
	{
		MessageTextPrivate m = new MessageTextPrivate(text, 
				this.wallet.getPrivateKey(), this.wallet.getPublicKey(),
				this.wallet.getName(), receiver);
		if(!this.sendMessageByKey(receiver, m)){
			this.sendMessageByAll(m);
		}
		return true;
	}
	
	protected void broadcastRequestForBlockchainUpdate()
	{
		MessageAskForBlockchainBroadcast m = new MessageAskForBlockchainBroadcast(
				"update blockchain", wallet.getPrivateKey(), wallet.getPublicKey(), wallet.getName());
		LogManager.log(Configuration.logMin(), "sending message for updating local blockchain of "+this.wallet.getName());
		this.sendMessageByAll(m);
	}
	
	/**
	 * 
	 * @param key
	 * @return	0 = no direct connection, 1 = has direct incoming connection, 2 = has direct outgoing connection;
	 *  3= has both direct incoming and outgoing connections
	 */
	protected int hasDirectConnection(PublicKey key)
	{
		int n = 0;
		String v = UtilityMethods.getKeyString(key);
		if(this.incomingConnections.get(v) != null && this.outgoingConnections.get(v) != null){
			n = 3;
		}else if(this.incomingConnections.get(v) != null){
			n = 1;
		}else if(this.outgoingConnections.get(v) != null){
			n = 2;
		}
		return n;
	}
	
	protected int numberOfExistingOutgoingConnections(){
		return this.outgoingConnections.size();
	}
	
	protected int numberOfExistingIncomingConnections(){
		return this.incomingConnections.size();
	}
}
