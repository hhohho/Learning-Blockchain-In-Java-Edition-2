package mdsky.applications.blockchain;

public class LogManager 
{
	public static void log(int logLevel, String message)
	{
		if(logLevel >= Configuration.logBar()){
			System.out.println(message);
		}
	}
}
