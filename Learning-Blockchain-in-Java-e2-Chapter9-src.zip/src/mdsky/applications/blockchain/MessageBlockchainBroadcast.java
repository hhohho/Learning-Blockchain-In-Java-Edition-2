package mdsky.applications.blockchain;

import java.security.PublicKey;

public class MessageBlockchainBroadcast extends Message
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private Blockchain ledger = null;
	private PublicKey sender = null;
	private int initialSize = 0; 
	private String uniqueHashID;
	private long timeStamp;
	
	public MessageBlockchainBroadcast(Blockchain ledger, PublicKey sender){
		this.ledger = ledger;
		this.sender = sender;
		this.initialSize = ledger.size();
		this.timeStamp = UtilityMethods.getTimeStamp();
		String v = UtilityMethods.getKeyString(sender)+this.timeStamp+UtilityMethods.getUniqueNumber();
		this.uniqueHashID = UtilityMethods.messageDigestSHA256_toString(v);
	}
	
	public int getInfoSize(){
		return this.initialSize;
	}
	
	public int getMessageType(){
		return Message.BLOCKCHAIN_BROADCAST;
	}
		
	//the message body
	public Blockchain getMessageBody(){
		return this.ledger;
	}
	
	public boolean isForBroadcast(){
		return true;
	}
	
	public PublicKey getSenderKey(){
		return this.sender;
	}
	
	public String getMessageHashID(){
		return this.uniqueHashID;
	}
	
	public long getTimeStamp(){
		return this.timeStamp;
	}
}
