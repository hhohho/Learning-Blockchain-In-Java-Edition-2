package mdsky.applications.blockchain;

import java.security.PublicKey;

public class MessageBlockBroadcast extends Message
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private Block block = null;
	private PublicKey sender;
	private long timeStamp;
	
	public MessageBlockBroadcast(Block block, PublicKey sender){
		this.block = block;
		this.timeStamp = UtilityMethods.getTimeStamp();
		this.sender = sender;
	}
	
	public int getMessageType(){
		return Message.BLOCK_BROADCAST;
	}
		
	//the message body
	public Block getMessageBody(){
		return this.block;
	}
	
	public boolean isForBroadcast(){
		return true;
	}
	
	/**
	 * For a block, since every block has a unique hashID, returning the block's hashID is good enough
	 */
	public String getMessageHashID(){
		return this.block.getHashID();
	}
	

	public long getTimeStamp(){
		return this.timeStamp;
	}
	
	public PublicKey getSenderKey(){
		return this.sender;
	}
	
	protected boolean selfMessageAllowed(){
		return true;
	}
}


