package mdsky.applications.blockchain;

import java.security.PrivateKey;
import java.security.PublicKey;

class MessageAskForBlockchainPrivate extends MessageTextPrivate
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private String uniqueHashID;
	private long timeStamp;
	private boolean must = false;
	public MessageAskForBlockchainPrivate(String text, PrivateKey prikey, PublicKey sender, 
			String name, PublicKey receiver, boolean must)
	{
		super(text, prikey, sender, name, receiver);
		this.timeStamp = UtilityMethods.getTimeStamp();
		String v = UtilityMethods.getKeyString(sender)+name+this.timeStamp+UtilityMethods.getUniqueNumber();
		this.uniqueHashID = UtilityMethods.messageDigestSHA256_toString(v);
		this.must = must;
	}
	
	public int getMessageType(){
		return Message.BLOCKCHAIN_ASK_PRIVATE;
	}
	
	public String getMessageHashID(){
		return this.uniqueHashID;
	}
	
	public long getTimeStamp(){
		return this.timeStamp;
	}
	
	public boolean isMust(){
		return this.must;
	}
}
