package mdsky.applications.blockchain;

import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;

public class PeerServer implements Runnable
{
	// The wallet this peer server is working on behalf of
	private Wallet wallet;
	private ServerSocket server;
	private static String IP = null;
	private boolean forever = true;
	private PeerConnectionManager connectionManager;
	private WalletMessageTaskManager messageManager;
	PeerServer(Wallet wallet, WalletMessageTaskManager messageManager, PeerConnectionManager connectionManager) throws Exception
	{
		this.wallet = wallet;
		this.connectionManager = connectionManager;
		this.messageManager = messageManager;
		server = new ServerSocket(Configuration.networkPort());
		PeerServer.IP = server.getInetAddress().getLocalHost().getHostAddress();
	}
	
	public static String getServerIP(){
		return PeerServer.IP;
	}
	
	public void run()
	{
		LogManager.log(Configuration.logMax(), "peer server of " + this.wallet.getName()+" is listening now");
		while(forever){
			try{
				if(this.connectionManager.numberOfExistingIncomingConnections() >= Configuration.incomingConnectionsLimit()){
					Thread.sleep(Configuration.threadSleepTimeLong() * 100);
				}else{
					Socket socket = this.server.accept();
					InetAddress clientAddress = socket.getInetAddress();
					LogManager.log(Configuration.logMax(),"Got an incoming connection request from " + clientAddress.getHostAddress());
					PeerIncomingConnection peer = new PeerIncomingConnection(wallet, socket, messageManager, connectionManager);
					Thread t = new Thread(peer);
					t.start();
					LogManager.log(Configuration.logMax(), "PeerIncomingConnection with "+peer.getConnectionIP()+" established");
					this.connectionManager.addIncomingConnection(peer);
				}
			}catch(Exception ioe){
				LogManager.log(Configuration.logMax(), "Exception in PeerServer.run()["+ioe.getMessage()); 
				forever = false;
			}
		}
		System.exit(0);
	}
}
