package mdsky.applications.blockchain;

import java.security.PrivateKey;
import java.security.PublicKey;

public class MessageAskForBlockchainBroadcast extends MessageTextBroadcast
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private String uniqueHashID;
	private long timeStamp;
	public MessageAskForBlockchainBroadcast(String text, PrivateKey prikey, PublicKey sender, String name)
	{
		super(text, prikey, sender, name);
		this.timeStamp = UtilityMethods.getTimeStamp();
		String v = UtilityMethods.getKeyString(sender)+name+this.timeStamp+UtilityMethods.getUniqueNumber();
		this.uniqueHashID = UtilityMethods.messageDigestSHA256_toString(v);
	}
	
	public int getMessageType(){
		return Message.BLOCKCHAIN_ASK_BROADCAST;
	}
	
	public String getMessageHashID(){
		return this.uniqueHashID;
	}
	
	public long getTimeStamp(){
		return this.timeStamp;
	}
}
