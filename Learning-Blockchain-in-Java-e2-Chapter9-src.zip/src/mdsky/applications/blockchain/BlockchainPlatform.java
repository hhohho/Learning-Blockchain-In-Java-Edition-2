package mdsky.applications.blockchain;

import java.util.ArrayList;

/**
 * The driver class to start the genesis miner first.
 * @author hzhou
 *
 */
public class BlockchainPlatform 
{
	public static void main(String[] args)
	{
		Miner genesisMiner = new Miner("genesis", "genesis");
		//create genesis block
		Block genesisBlock = new Block("0", Configuration.blockMiningDifficultyLevel(), genesisMiner.getPublicKey());
		UTXO u1 = new UTXO("0", genesisMiner.getPublicKey(), genesisMiner.getPublicKey(), 1000001.0);
		UTXO u2 = new UTXO("0", genesisMiner.getPublicKey(), genesisMiner.getPublicKey(), 1000000.0);
		ArrayList<UTXO> inputs = new ArrayList<UTXO>();
		inputs.add(u1);
		inputs.add(u2);
		Transaction gt = new Transaction(genesisMiner.getPublicKey(), genesisMiner.getPublicKey(), 1000000.0, inputs);
		boolean b = gt.prepareOutputUTXOs();
		if(!b){
			System.out.println("genesis transaction failed.");
			System.exit(1);
		}
		gt.signTheTransaction(genesisMiner.getPrivateKey());
		b = genesisBlock.addTransaction(gt, genesisMiner.getPublicKey());
		if(!b){
			System.out.println("failed to add the genesis transaction to the genesis block. System quit");
			System.exit(2);
		}
		//the genesis miner mines the genesis block
		System.out.println("genesis miner is mining the genesis block");
		b = genesisMiner.mineBlock(genesisBlock);
		if(b){
			System.out.println("genesis block is successfully mined. HashID:");
			System.out.println(genesisBlock.getHashID());
		}else{
			System.out.println("failed to mine genesis block. System exit");
			System.exit(3);
		}
		Blockchain ledger = new Blockchain(genesisBlock);
		System.out.println("block chain genesis successful");
		//genesisMiner copies the blockchain to his local ledger
		genesisMiner.setLocalLedger(ledger);
		System.out.println("genesis miner local copy of blockchain set.");
		System.out.println("genesis miner balance: " + genesisMiner.getCurrentBalance(genesisMiner.getLocalLedger()));
		
		try{
			MinerMessageTaskManager manager = null;
			PeerConnectionManager agent = new PeerConnectionManager(genesisMiner, manager);
			manager = new MinerGenesisMessageTaskManager(genesisMiner, agent);
			agent.setWalletMessageTaskManager(manager);
			PeerServer peerServer = new PeerServer(genesisMiner, manager, agent);
			Thread managerThread = new Thread(manager);
			Thread agentThread = new Thread(agent);
			Thread serverThread = new Thread(peerServer);
			WalletSimulator simulator = new WalletSimulator(genesisMiner, agent, manager);
			manager.setSimulator(simulator);
			serverThread.start();
			System.out.println("peer server started");
			agentThread.start();
			System.out.println("peer clients manager started");
			managerThread.start();
			System.out.println("wallet task manager started");
			simulator.setBalanceShowPublicKey(false);
			System.out.println("Genesis miner is up, blockchain platform ready. IP address="+PeerServer.getServerIP());
		}catch(Exception e){
			e.printStackTrace();
			System.exit(1);
		}
	}
	
}

