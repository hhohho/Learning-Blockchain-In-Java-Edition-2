package mdsky.applications.blockchain;

import java.net.Socket;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.security.PublicKey;

public class PeerIncomingConnection implements Runnable
{
	private Wallet wallet;
	private Socket socket;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	//the public key of the peer that this connection is connected to 
	private PublicKey connectionPeerPubkey;
	//the name of the peer that this connection is connected to 
	private String connectionPeerName;
	private boolean forever = true;
	private PeerConnectionManager connectionManager;
	private WalletMessageTaskManager messageManager;
	
	public PeerIncomingConnection(Wallet wallet, Socket socket, 
			WalletMessageTaskManager messageManager, PeerConnectionManager connectionManager) throws Exception
	{
		this.wallet = wallet;
		this.messageManager = messageManager;
		this.connectionManager = connectionManager;
		this.socket = socket;
		this.out = new ObjectOutputStream(this.socket.getOutputStream());
		this.in = new ObjectInputStream(this.socket.getInputStream());
		// sends a MessageID 
		MessageID mid = new MessageID(this.wallet.getPrivateKey(),this.wallet.getPublicKey(), this.wallet.getName());
		this.out.writeObject(mid);
		MessageID md = (MessageID)this.in.readObject();
		this.connectionPeerPubkey = md.getSenderKey();
		this.connectionPeerName = md.getName();
		MessageAskForBlockchainPrivate mabcb = (MessageAskForBlockchainPrivate)this.in.readObject();
		if(mabcb.isMust()){
			PublicKey receiver = mabcb.getSenderKey();
			Blockchain bc = this.wallet.getLocalLedger().copy_NotDeepCopy();
			MessageBlockchainPrivate message = new MessageBlockchainPrivate(bc, 	
					wallet.getPublicKey(), receiver);
			this.sendMessage(message);
		}
		this.connectionManager.addAddress(md.getKeyNamePair());
	}
	
	
	public void run()
	{
		while(forever){
			try{
				Thread.sleep(Configuration.threadSleepTimeMedium());
			}catch(InterruptedException ie){
				LogManager.log(Configuration.logMin(), "Exception in PeerIncomingConnection.run()-1["+ie.getMessage()); 
				activeClose();
			}
			try{
				Message m = (Message)this.in.readObject();
				LogManager.log(Configuration.logMin(),"got a message in IncomingConnection:"+m.getMessageType()+"|"+m.getMessageBody());
				if(m.getMessageType() == Message.TEXT_PRIVATE_CLOSE_CONNECTION){
					//making sure that it is from the correct sender
					MessageTextCloseConnectionPrivate mp = (MessageTextCloseConnectionPrivate)m;
					if(mp.getSenderKey().equals(this.connectionPeerPubkey) 
							&& mp.getReceiver().equals(this.wallet.getPublicKey())){
						LogManager.log(Configuration.logMax(),"The incomingConnection from "+ getConnectionIP() + "/" 
								+ this.connectionPeerName +" is requested to be terminated.");
						this.connectionManager.removePeerConnection(this);
						this.close();
					}
				}else{
					this.messageManager.addMessageIntoQueue(m);
				}
			}catch(Exception ioe){
				LogManager.log(Configuration.logMin(), "Exception in PeerIncomingConnection.run()-2["+ioe.getMessage()); 
				this.close();
			}
		}
	}
	
	protected synchronized boolean sendMessage(Message m)
	{
		if(m == null){
			return false;
		}
		try{
			this.out.writeObject(m);
			return true;
		}catch(IOException e){
			LogManager.log(Configuration.logMax(), "Exception in PeerIncomingConnection.sendMessage()["
						+"type="+m.getMessageType()+"]"+e.getMessage());
			//needs to close and remove this connection
			this.close();
		}
		return false;
	}
	
	/**
	 * A close action initiated by the peer owning this connection, i.e, the close action
	 * is initiated on this end of the connection. Such an action requires a connection-close-message
	 * to be sent to another end of the connection.
	 */
	protected synchronized void activeClose()
	{
		MessageTextCloseConnectionPrivate mc = new MessageTextCloseConnectionPrivate(this.wallet.getPrivateKey(),
				this.wallet.getPublicKey(), this.wallet.getName(), this.connectionPeerPubkey);
		try{
			this.out.writeObject(mc);
			Thread.sleep(Configuration.threadSleepTimeShort());
		}catch(Exception ee){
			LogManager.log(Configuration.logMin(), "Exception in PeerIncomingConnection.activeClose()["+ee.getMessage()); 
		}
		this.close();
		
	}
	
	private synchronized void close()
	{
		this.forever = false;
		try{
			this.in.close();
			this.out.close();
		}catch(Exception e){
			LogManager.log(Configuration.logMin(), "Exception in PeerIncomingConnection.close()["+e.getMessage()); 
		}
		connectionManager.removePeerConnection(this);
		LogManager.log(Configuration.logMin(), "IncomingConnection from " + this.getConnectionIP()+"/"
						+ this.connectionPeerName +" is closed");
	} 
	
	public String getConnectionIP(){
		return this.socket.getInetAddress().getHostAddress();
	}
	
	public PublicKey getConnectionPeerPublicKey(){
		return this.connectionPeerPubkey;
	}
	
	public String getConnectionPeerName(){
		return this.connectionPeerName;
	}
	
	/**
	 * Obtain the KeyNamePair of the peer on another end of the connection
	 * @return
	 */
	public KeyNamePair getConnectionPeerNamePair(){
		return new KeyNamePair(this.connectionPeerPubkey, this.connectionPeerName);
	}
}
