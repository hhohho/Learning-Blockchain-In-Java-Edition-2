package mdsky.applications.blockchain;

public class TestWallet_1 {
	public static void main(String[] args)
	{
		java.util.Scanner in = new java.util.Scanner(System.in);
		System.out.println("To create a wallet, please give your name:");
		String name = in.nextLine();
		System.out.println("please create a password");
		String password = in.nextLine();
		in.close();
		Wallet w = new Wallet(name, password);
		System.out.println("wallet created for " + w.getName());
		//let's load this wallet
		Wallet w2 = new Wallet(name, password);
		System.out.println("wallet loaded successfully, wallet name="+w2.getName());			
	}
}
