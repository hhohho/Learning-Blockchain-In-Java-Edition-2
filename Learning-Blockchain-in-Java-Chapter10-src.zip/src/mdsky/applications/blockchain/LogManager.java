package mdsky.applications.blockchain;

/**
 * A new class added in Chapter 9 to control the log messages.
 * @author hzhou
 *
 */
public class LogManager 
{
	/**
	 * A text can only be displayed through the standard output if the logLevel is >= the logBar which 
	 * can be adjusted in the Configuration class. So, if you do not want to view any log messages,
	 * you can raise the logBar in the Configuration class.
	 * @param logLevel
	 * @param message
	 */
	public static void log(int logLevel, String text)
	{
		if(logLevel >= Configuration.logBar()){
			System.out.println(text);
		}
	}
}
