package mdsky.applications.blockchain;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * A wallet can initiate a network connection to a peer that provides server service.
 * A PeerClient is a client connection of a Wallet to another peer server.
 * To initiate a PeerClient, the following information is required:
 * <li>A peer server address (IP address)
 * <li>Protocol port number
 * <li>The wallet who initiates this connection
 * <li>In this implementation, a peer client is an outgoing network connection,
 * i.e. a peer client only sends out message.
 * </li>
 * From a PeerClient, the following information can be deduced:
 * <li>The Peer information at the peer-server side, including its publicKey, and name
 * <li>
 * </li>
 * Important:  this PeerClient does not need to implement Runnable, i.e. it does not need to be
 * an independent process if its function is only for sending messages.  
 * @author hzhou
 *
 */
public class PeerClient //implements Runnable
{
	private Wallet wallet;
	private Socket socket;
	private String peerServerIP;
	private ObjectInputStream in;
	private ObjectOutputStream out;
	private PublicKey peerServerPubkey;
	private String peerServerName;
	private boolean forever = true;
	private PeerClientsManager clientManager;
	
	protected PeerClient(String serverIP, int port, Wallet wallet, PeerClientsManager clientManager) throws Exception
	{
		this.wallet = wallet;
		this.clientManager = clientManager;
		LogManager.log(Configuration.logMax(), wallet.getName()+" is creating a peer client connection to " + serverIP);
		this.peerServerIP = serverIP;
        socket = new Socket(serverIP, port);
        out = new ObjectOutputStream(socket.getOutputStream());
        in = new ObjectInputStream(socket.getInputStream());
        //the peer client will get a MessageForID from the peer server
        MessageID fromPeerServer = (MessageID)in.readObject();
        //make sure that the message is in good standing
        if(fromPeerServer.isValid()){
        	this.peerServerPubkey = fromPeerServer.getSenderKey();
        	this.peerServerName = fromPeerServer.getName();
        }else{
        	throw new Exception("MessageID from service provider is invalid.");
        }
        //if everything works well, the agent sends the server a responding MessageForID
        //because the server is waiting for the client to send in a MessageForID
        LogManager.log(Configuration.logMax(), "obtained server address and stored it, now sending wallet public key to server");
        LogManager.log(Configuration.logMax(), "name="+this.wallet.getName());
        MessageID mid = new MessageID(this.wallet.getPrivateKey(), this.wallet.getPublicKey(), this.wallet.getName());
        out.writeObject(mid);
        LogManager.log(Configuration.logMax(), "A peer client connection to " + this.peerServerPubkey + " is established successfully.");
        if(this.wallet.getLocalLedger() == null){
        	//directly asks for a blockchain before doing anything
        	MessageAskForBlockchainBroadcast m = new MessageAskForBlockchainBroadcast(
    				"update blockchain", wallet.getPrivateKey(), wallet.getPublicKey(), wallet.getName());
        	out.writeObject(m);
        	//wait for such a response
        	MessageBlockchainPrivate mbcb = (MessageBlockchainPrivate)in.readObject();
        	LogManager.log(Configuration.logMin(), "In PeerClient.constructor["
        				+"It is a blockchain private message, check if it is for me and if necessary to update the blockchain");
        	boolean b = this.wallet.setLocalLedger(mbcb.getMessageBody());
        	if(b){
        		LogManager.log(Configuration.logMax(), "blockchain updated successfully");
        	}else{
        		LogManager.log(Configuration.logMax(), "In PeerClient.constructor["
        				+ "blockchain update failed for " + this.wallet.getName()+" from "+ this.getPeerServerIP());
        		throw new RuntimeException("In PeerClient.constructor["
        				+ "blockchain update failed for " + this.wallet.getName()+" from "+ this.getPeerServerIP());
        	}
        }
	}
	
	/*
	public void run()
	{
		while(forever){
			try{
				Thread.sleep(Configuration.threadSleepTimeLong());
				//Still accepting messages from the peer-server.
				//If the message is to close the connection from the peer server, 
				//this peer client should terminate.
				Message m = (Message)in.readObject();
				if(m.getMessageType() == Message.TEXT_PRIVATE_CLOSE_CONNECTION){
					MessageTextCloseConnectionPrivate mp = (MessageTextCloseConnectionPrivate)m;
					if(mp.getSenderKey().equals(this.peerServerPubkey) 
							&& mp.getReceiver().equals(this.wallet.getPublicKey())){
						this.close();
						LogManager.log(Configuration.logMax(), this.peerServerIP+" initiates connection close, the peer client is closing now.");
					}
				}
			}catch(Exception e){
				LogManager.log(Configuration.logMax(), "Exception In PeerClient.run()|"+this.getPeerServerIP()+"[ "+e.getMessage());
				forever = false;
			}
		}
		LogManager.log(Configuration.logMax(), "Peer client connection to " + this.peerServerIP+" is terminated.");
	}
	*/
	public synchronized boolean sendMessage(Message m)
	{
		//double ensure that all null message is not sent
		if(m == null){
			LogManager.log(Configuration.logMin(), "message is null, cannot send");
			return false;
		}
		try{
			this.out.writeObject(m);
			return true;
		}catch(Exception e){
			LogManager.log(Configuration.logMax(), "Exception in PeerClient.sendMessage()|"+this.getPeerServerIP()
				+"|failed to send message [" + e.getMessage());
			//now we need to re-connect
			//if(e instanceof java.net.SocketException){
				this.clientManager.recreatePeerClient(this);
			//}
			return false;
		}
	}
	
	public PublicKey getPeerServerPublicKey(){
		return this.peerServerPubkey;
	}
	
	public String getPeerServerName(){
		return this.peerServerName;
	}
	
	public KeyNamePair getPeerServerKeyNamePair(){
		return new KeyNamePair(this.peerServerPubkey, this.peerServerName);
	}
	
	public String getPeerServerIP(){
		return this.peerServerIP;
	}
	
	protected synchronized void activeClose()
	{
		MessageTextPrivate mc = new MessageTextPrivate(Message.TEXT_CLOSE, this.wallet.getPrivateKey(),
				this.wallet.getPublicKey(), this.wallet.getName(), this.getPeerServerPublicKey());
		this.sendMessage(mc);
		try{
			Thread.sleep(Configuration.threadSleepTimeShort());
		}catch(Exception ee){
			LogManager.log(Configuration.logMax(), "Exception in PeerClient.activeClose()|"+this.getPeerServerIP()+"["+ee.getMessage());
		}
		this.close();
	}
	
	protected synchronized void close()
	{
		this.forever = false;
		try{
			this.in.close();
			this.out.close();
		}catch(Exception e){
			
		}
	} 
}
