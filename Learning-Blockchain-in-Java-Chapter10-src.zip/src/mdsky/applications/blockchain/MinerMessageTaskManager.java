package mdsky.applications.blockchain;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;

public class MinerMessageTaskManager extends WalletMessageTaskManager implements Runnable
{
	private boolean miningAction = true;
	private ArrayList<Transaction> existingTransactions = new ArrayList<Transaction>();
	private Miner miner;
	private PeerClientsManager clientManager;
	
	public MinerMessageTaskManager(Miner miner, PeerClientsManager clientsManager)
	{
		super(miner, clientsManager);
		this.miner = miner;
		this.clientManager = clientsManager;
	}
	
	protected synchronized void resetMiningAction(){
		this.miningAction = true;
	}
	
	protected synchronized boolean getMiningAction(){
		return this.miningAction;
	}
	
	protected synchronized void raiseMiningAction(){
		this.miningAction = false;
	}
	
	protected void receiveMessageForBlockchainBroadcast(MessageAskForBlockchainBroadcast mabcb)
	{
		PublicKey receiver = mabcb.getSenderKey();
		Blockchain bc = miner.getLocalLedger().copy_NotDeepCopy();
		MessageBlockchainPrivate message = new MessageBlockchainPrivate(bc, 	
						miner.getPublicKey(), receiver);
		if(!this.clientManager.sendMessageByKey(receiver, message)){
			this.clientManager.sendMessageByAll(message);
		}
	}
	
	
	protected void receiveMessageTransactionBroadcast(MessageTransactionBroadcast mtb)
	{
		//forward it first
		this.clientManager.sendMessageByAll(mtb);
		//now process it
		Transaction ts = mtb.getMessageBody();
		//first, make sure that this transaction does not exist in the current pool
		for(int i=0; i<this.existingTransactions.size(); i++){
			if(ts.equals(this.existingTransactions.get(i))){
				return;
			}
		}
		//add this into the existing storage
		if(!miner.validateTransaction(ts)){
			System.out.println("Miner "+ miner.getName()+" found an invalid transaction. Should broadcast it though");
			return;
		}
		this.existingTransactions.add(ts);
		//check if it meets the requirement to build a block
		if(this.existingTransactions.size() >= Configuration.blockTransactionNumberLowerLimit() 
				&& this.getMiningAction() ){
			this.raiseMiningAction();
			LogManager.log(Configuration.logMax(),miner.getName()+" has enough transactions to mine the block now, " 
					+"mining_action_block_size requirement meets. Start mining a new block");
			//Modification in Chapter 9: 
			//copy transactions into another arraylist for the work to build a block.
			//Remove those transactions from the original pool once copied.
			ArrayList<Transaction> tts = new ArrayList<Transaction>();
			for(int i=0,j=0; i<this.existingTransactions.size() && j<Configuration.blockTransactionNumberUpperLimit(); i++,j++){
				tts.add(this.existingTransactions.get(i));
				this.existingTransactions.remove(i);
				i--;
			}
			MinerTheWorker worker = new MinerTheWorker(miner, this, this.clientManager, tts);
			Thread miningThread = new Thread(worker);
			miningThread.start();
			//Modification in chapter 9:
			//this.existingTransactions = new ArrayList<Transaction>(); 		
		}
	}
	
	/**
	 * Modification in chapter 9:
	 * Overwrite this method so that when a block is accepted, the miner needs to 
	 * re-examine its transaction pool in case some existing transactions should be
	 * invalidated by this newly accepted block.
	 */
	protected boolean receiveMessageBlockBroadcast(MessageBlockBroadcast mbb)
	{
		boolean b = super.receiveMessageBlockBroadcast(mbb);
		if(b){
			Block block = mbb.getMessageBody();
			//now examine if any transactions in the pool also exist inside this block
			//If does, remove it from the pool
			for(int i=0; i<block.getTotalNumberOfTransactions(); i++){
				Transaction t = block.getTransaction(i);
				//test if t exists in the pool
				for(int j=0; j<this.existingTransactions.size(); j++){
					Transaction t2 = this.existingTransactions.get(j);
					if(t.equals(t2)){
						this.existingTransactions.remove(j);
						break;
					}
				}
			}
		}
		return b;
	}
}

