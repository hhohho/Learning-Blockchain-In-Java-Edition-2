package mdsky.applications.blockchain;

import java.util.ArrayList;
import java.security.PublicKey;

public class MessageAddressPrivate extends Message
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<KeyNamePair> addresses;
	private PublicKey sender;
	private String uniqueHashID;
	private PublicKey receiver;
	private long timeStamp = 0;
	
	public MessageAddressPrivate(ArrayList<KeyNamePair> addresses, PublicKey sender, PublicKey receiver)
	{
		this.addresses = addresses;
		this.sender = sender;
		this.receiver = receiver;
		this.timeStamp = UtilityMethods.getTimeStamp();
		String v = UtilityMethods.getKeyString(sender) + UtilityMethods.getKeyString(receiver)
					+ this.timeStamp + UtilityMethods.getUniqueNumber();
		this.uniqueHashID = UtilityMethods.messageDigestSHA256_toString(v);
	}
	
	public int getMessageType(){
		return Message.ADDRESS_PRIVATE;
	}
		
	//the message body
	public ArrayList<KeyNamePair> getMessageBody(){
		return this.addresses;
	}
	
	public boolean isForBroadcast(){
		return false;
	}
	
	public String getMessageHashID(){
		return this.uniqueHashID;
	}
	
	public long getTimeStamp(){
		return this.timeStamp;
	}
	
	public PublicKey getSenderKey(){
		return this.sender;
	}
	
	public PublicKey getReceiverKey(){
		return this.receiver;
	}
}
