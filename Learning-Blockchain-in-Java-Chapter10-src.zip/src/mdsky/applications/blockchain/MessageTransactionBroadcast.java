package mdsky.applications.blockchain;

import java.security.PublicKey;

public class MessageTransactionBroadcast extends Message 
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private Transaction transaction = null;
	private long timeStamp;
	
	public MessageTransactionBroadcast(Transaction transaction)
	{
		this.transaction = transaction;
		this.timeStamp = UtilityMethods.getTimeStamp();
	}
	
	public int getMessageType(){
		return Message.TRANSACTION_BROADCAST;
	}
		
	//the message body
	public Transaction getMessageBody(){
		return this.transaction;
	}
	
	public boolean isForBroadcast(){
		return true;
	}
	
	public String getMessageHashID(){
		//return this.uniqueHashID;
		return this.transaction.getHashID();
	}
	
	public long getTimeStamp(){
		return this.timeStamp;
	}
	
	public PublicKey getSenderKey(){
		return this.transaction.getSender();
	}
	
	protected boolean selfMessageAllowed(){
		return true;
	}
}

