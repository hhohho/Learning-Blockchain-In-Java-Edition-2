package mdsky.applications.blockchain;

import java.util.ArrayList;


public class LedgerList<T> implements java.io.Serializable
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<T> list;
	
	public LedgerList(){
		list = new ArrayList<T>();
	}
	
	public int size(){
		return this.list.size();
	}
	
	public T getLast(){
		return this.list.get(size()-1);
	}
	
	public T getFirst(){
		return this.list.get(0);
	}
	
	public boolean add(T e){
		return this.list.add(e);
	}
	
	/**
	 * If index is outside of the range, null is returned.
	 * @param index
	 * @return
	 */
	public T findByIndex(int index)
	{
		if(index < 0  || index >= size()){
			return null;
		}else{
			return this.list.get(index);
		}
	}
}
