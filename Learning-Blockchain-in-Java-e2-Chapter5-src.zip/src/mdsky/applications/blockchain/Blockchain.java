package mdsky.applications.blockchain;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.HashMap;

public class Blockchain implements java.io.Serializable
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;
	public static final double MINING_REWARD = 100.0;
	private LedgerList<Block> blockchain; 
	
	public Blockchain(Block genesisBlock)
	{
		this.blockchain = new LedgerList<Block>();
		this.blockchain.add(genesisBlock);
	}

	/**
	 * add a Block to the end of the existing chain.
	 * @param block
	 */
	public synchronized void addBlock(Block block)
	{
		if(block.getPreviousBlockHashID().equals(this.getLastBlock().getHashID())){
			this.blockchain.add(block);
		}
	}
	
	public Block getGenesisBlock(){
		return this.blockchain.getFirst();
	}
	
	public Block getLastBlock()
	{
		return this.blockchain.getLast();
	}
	
	public int size(){
		return this.blockchain.size();
	}
	
	public Block getBlock(int index){
		return this.blockchain.findByIndex(index);
	}
	
	/**
	 * check the balance belonging to this public key address
	 * @param key
	 * @return
	 */
	public double checkBalance(PublicKey key)
	{
		ArrayList<UTXO> all = new ArrayList<UTXO>();
		ArrayList<UTXO> spent = new ArrayList<UTXO>();
		ArrayList<UTXO> unspent = new ArrayList<UTXO>();
		return findRelatedUTXOs(key, all, spent, unspent);
	}
	
	
	/**
	 * 
	 * @param key
	 * @param all
	 * @param spent  does not include the spent UTXO in the genesis block
	 * @param unspent
	 * @param sendingTransactions  it does not include the transactions in the genesis block
	 * @return
	 */
	public double findRelatedUTXOs(PublicKey key, ArrayList<UTXO> all, ArrayList<UTXO> spent, 
			ArrayList<UTXO> unspent, ArrayList<Transaction> sentTransactions)
	{
		double gain = 0.0, spending = 0.0;
		HashMap<String, UTXO> map = new HashMap<String, UTXO>();
		int limit = this.size();
		for(int a=0; a<limit; a++){
			Block block = this.blockchain.findByIndex(a);
			int size = block.getTotalNumberOfTransactions();
			for(int i=0; i<size; i++){
				Transaction T = block.getTransaction(i);
				int N;
				if(a != 0 && T.getSender().equals(key)){
					N = T.getNumberOfInputUTXOs();
					for(int x=0; x<N; x++){
						UTXO ut = T.getInputUTXO(x);
						spent.add(ut);
						map.put(ut.getHashID(), ut);
						spending += ut.getFundTransferred();
					}
					sentTransactions.add(T);
				}
				
				N = T.getNumberOfOutputUTXOs();
				for(int x=0; x<N; x++){
					UTXO ux = T.getOuputUTXO(x);
					if(ux.getReceiver().equals(key)){
						all.add(ux);
						gain += ux.getFundTransferred();
					}
				}
			}
		}
		for(int i=0; i<all.size();i++){
			UTXO ut = all.get(i);
			if(!map.containsKey(ut.getHashID())){
				unspent.add(ut);
			}
		}
		return (gain - spending);
	}
	
	public double findRelatedUTXOs(PublicKey key, ArrayList<UTXO> all, ArrayList<UTXO> spent, ArrayList<UTXO> unspent)
	{
		ArrayList<Transaction> sendingTransactions = new ArrayList<Transaction>();
		return findRelatedUTXOs(key, all, spent, unspent, sendingTransactions);
	}
	
	
	public ArrayList<UTXO> findUnspentUTXOs(PublicKey key)
	{
		ArrayList<UTXO> all = new ArrayList<UTXO>();
		ArrayList<UTXO> spent = new ArrayList<UTXO>();
		ArrayList<UTXO> unspent = new ArrayList<UTXO>();
		findRelatedUTXOs(key, all, spent, unspent);
		return unspent;
	}
	
	public double findUnspentUTXOs(PublicKey key, ArrayList<UTXO> unspent)
	{
		ArrayList<UTXO> all = new ArrayList<UTXO>();
		ArrayList<UTXO> spent = new ArrayList<UTXO>();
		return findRelatedUTXOs(key, all, spent, unspent);
	}
}
