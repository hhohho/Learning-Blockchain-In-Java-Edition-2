package mdsky.applications.blockchain;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.ArrayList;

public class Wallet 
{
	private KeyPair keyPair;
	private String walletName;
	private static String keyLocation = "keys";
	private Blockchain localLedger = null;
	
	public Wallet(String walletName, String password)
	{
		this.keyPair = UtilityMethods.generateKeyPair();
		this.walletName = walletName;
		try{
			populateExistingWallet(walletName, password);
			System.out.println("A wallet exists with the same name and password. Loaded the existing wallet");
		}catch(Exception ee){
			try{
				this.prepareWallet(password);
				System.out.println("Created a new wallet based on the name and password");
			}catch(IOException ioe){
				throw new RuntimeException(ioe);
			}
		}
	}
	
	public Wallet(String walletName)
	{
		this.keyPair = UtilityMethods.generateKeyPair();
		this.walletName = walletName;
	}
	
	public String getName()
	{
		return this.walletName;
	}

	public PublicKey getPublicKey()
	{
		return this.keyPair.getPublic();
	}
	

	protected PrivateKey getPrivateKey()
	{
		return this.keyPair.getPrivate();
	}	
	
	private void prepareWallet(String password) throws IOException,FileNotFoundException
	{
		ByteArrayOutputStream bo = new ByteArrayOutputStream();
		ObjectOutputStream out = new ObjectOutputStream(bo);
		out.writeObject(this.keyPair);
		//let's use XOR encryption first
		byte[] keyBytes = UtilityMethods.encryptionByXOR(bo.toByteArray(), password);
		//byte[] keyBytes = UtilityMethods.encryptionByAES(bo.toByteArray(), password);
		//now, write this into a file
		File F = new File(Wallet.keyLocation);
		if(!F.exists()){
			F.mkdir();
		}
		FileOutputStream fout = new FileOutputStream(Wallet.keyLocation+"/"+this.getName()+"_keys");
		fout.write(keyBytes);
		fout.close();
		bo.close();
	}
	
	

	private void populateExistingWallet(String walletName, String password) 
			throws IOException, FileNotFoundException, ClassNotFoundException
	{
		FileInputStream fin = new FileInputStream(Wallet.keyLocation+"/"+walletName+"_keys");
		byte[] bb = new byte[4096];
		int size = fin.read(bb);
		fin.close();
		byte[] data = new byte[size];
		for(int i=0; i<data.length; i++){
			data[i] = bb[i];
		}
		//the data for the object KeyPair
		byte[] keyBytes = UtilityMethods.decryptionByXOR(data, password);
		ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(keyBytes));
		this.keyPair = (KeyPair)(in.readObject());
		this.walletName = walletName;
	}
	
	public synchronized Blockchain getLocalLedger()
	{
		return this.localLedger;
	}
	
	public synchronized boolean setLocalLedger(Blockchain ledger){
		this.localLedger = ledger;
		return true;
	}
	
	
	public Transaction transferFund(PublicKey receiver, double fundToTransfer)
	{
		PublicKey[] receivers = new PublicKey[1];
		double[] funds = new double[1];
		receivers[0] = receiver;
		funds[0] = fundToTransfer;
		return transferFund(receivers, funds);
	}
	

	public Transaction transferFund(PublicKey[] receivers, double[] fundToTransfer)
	{
		ArrayList<UTXO> unspent = new ArrayList<UTXO>();
		double available = this.getLocalLedger().findUnspentUTXOs(this.getPublicKey(), unspent);
		double totalNeeded = Transaction.TRANSACTION_FEE;
		for(int i=0; i<fundToTransfer.length; i++){
			totalNeeded += fundToTransfer[i];
		}
		if(available < totalNeeded){
			System.out.println(this.walletName+" balance="+available+", not enough to make the transfer of "+totalNeeded);
			return null;
		}
		//create input for the transaction
		ArrayList<UTXO> inputs = new ArrayList<UTXO>();
		available = 0;
		for(int i=0; i<unspent.size() && available < totalNeeded; i++){
			UTXO uxo = unspent.get(i);
			available += uxo.getFundTransferred();
			inputs.add(uxo);
		}
		
		//create the Transaction
		Transaction T = new Transaction(this.getPublicKey(), receivers, fundToTransfer, inputs);
		
		//sign the transaction
		boolean b = T.prepareOutputUTXOs();
		if(b){
			T.signTheTransaction(this.getPrivateKey());
			return T;
		}else{
			return null;
		}
	}
	
	public double getCurrentBalance(Blockchain ledger)
	{
		return ledger.checkBalance(this.getPublicKey());
	}
	
}




