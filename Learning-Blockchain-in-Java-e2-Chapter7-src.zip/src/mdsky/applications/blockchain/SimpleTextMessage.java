package mdsky.applications.blockchain;

public class SimpleTextMessage implements java.io.Serializable
{
	private static final long serialVersionUID = 1L;
	private String name;
	private String message;
	
	public SimpleTextMessage(String senderName, String message)
	{
		this.name = senderName;
		this.message = message;
	}
	
	public String getSenderName(){
		return this.name;
	}
	
	public String getMessage(){
		return this.message;
	}
}
