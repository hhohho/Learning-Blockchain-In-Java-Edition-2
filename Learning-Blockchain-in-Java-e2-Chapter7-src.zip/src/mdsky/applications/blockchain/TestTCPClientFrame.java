package mdsky.applications.blockchain;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Container;
import java.awt.Color;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.net.Socket;

public class TestTCPClientFrame extends JFrame
{
	private JTextArea textInput;
	private JButton sentButton;
	private JTextArea displayArea;
    private GridBagLayout mgr = null;
    private GridBagConstraints gcr = null;
    private MessageManagerTCP_x messenger;
    private ObjectOutputStream out;
    private ObjectInputStream in;
	public TestTCPClientFrame(String name, String ip) throws Exception
	{
		super(name);
		setUp();
		Socket socket = new Socket(ip, 8888);
		this.out = new ObjectOutputStream(socket.getOutputStream());
		this.in = new ObjectInputStream(socket.getInputStream());
		this.sendMessage(name);
		MessageManagerTCP_x messenger = new MessageManagerTCP_x(in, this.displayArea);
		Thread t = new Thread(messenger);
		t.start();
		this.addWindowListener(new java.awt.event.WindowAdapter(){
			public void windowClosing(java.awt.event.WindowEvent e){
				//close all thread if here is one
				try{
					messenger.close();
				}catch(Exception e1){}
				try{
					sendMessage("END");
				}catch(Exception ee){}
				dispose();
				System.exit(2);
			}
			
		});
	}
	
	protected void sendMessage(String mesg)
	{
		try{
			this.out.writeObject(mesg);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	private void setUp()
	{
		this.setSize(500, 400);
        Container c = getContentPane();
        mgr = new GridBagLayout();
        gcr = new GridBagConstraints();
        c.setLayout(mgr);      
        JLabel lblInput = new JLabel("Message Board");
        this.displayArea = new JTextArea(50, 100);
        this.textInput = new JTextArea(5, 100);
        this.sentButton = new JButton("Click me or hit enter to send the message below");
        this.sentButton.addActionListener(new java.awt.event.ActionListener(){
        	public void actionPerformed(java.awt.event.ActionEvent e){
        		try{
        			sendMessage(textInput.getText());
        		}catch(Exception e2){
        			System.out.println("Error: " + e2.getMessage());
        			throw new RuntimeException(e2);
        		}
        		textInput.setText("");
        	}
        });
        
        this.gcr.fill = GridBagConstraints.BOTH;
        this.gcr.weightx = 1;
        this.gcr.weighty = 0.0;
        this.gcr.gridx = 0;
        this.gcr.gridy = 0;
        this.gcr.gridwidth = 1;
        this.gcr.gridheight = 1;
        this.mgr.setConstraints(lblInput, this.gcr);
        c.add(lblInput);
        
        this.gcr.weighty = 0.9;
        this.gcr.gridx = 0;
        this.gcr.gridy = 1;
        this.gcr.gridheight = 9;
        JScrollPane scroll = new JScrollPane(this.displayArea);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        this.mgr.setConstraints(scroll, this.gcr);
        c.add(scroll);
        this.displayArea.setEditable(false);
        this.displayArea.setBackground(Color.LIGHT_GRAY);
        
        this.gcr.weighty = 0.0;
        this.gcr.gridx = 0;
        this.gcr.gridy = 11;
        this.gcr.gridheight = 1;
        this.mgr.setConstraints(this.sentButton, this.gcr);
        c.add(this.sentButton);
        
        this.gcr.weighty = 0.1;
        this.gcr.gridx = 0;
        this.gcr.gridy = 12;
        this.gcr.gridheight = 2;
        JScrollPane scroll2 = new JScrollPane(this.textInput);
		scroll2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		scroll2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        this.mgr.setConstraints(scroll2, this.gcr);
        c.add(scroll2);
        //add a key listener to the textarea
        this.textInput.addKeyListener(new KeyListener(){
        	public void keyTyped(KeyEvent e) {}
        		public void keyReleased(KeyEvent e) {}
        		public void keyPressed(KeyEvent e) {
        			int key = e.getKeyCode();
        			if (key == KeyEvent.VK_ENTER) {
        				//allow using shift+ENTER or control+ENTER to get an ENTER
        				if(e.isShiftDown() || e.isControlDown()){
        					textInput.append(System.getProperty("line.separator"));
        				}else{
	        				try{
	                			sendMessage(textInput.getText());
	                		}catch(Exception e2){
	                			System.out.println("Error: " + e2.getMessage());
	                			throw new RuntimeException(e2);
	                		}
	        				//consume the ENTER so that the cursor will stay at the beginning
	        				e.consume();
	                		textInput.setText("");
        				}
        			}
        	     }
        	}
        );        
		this.setVisible(true);
	}
	
	
	
	public static void main(String[] args)
	{
		String name = JOptionPane.showInputDialog("Please enter your unique name. Thanks:");
		String ip = JOptionPane.showInputDialog("Please enter the server IP address here:");
		if(ip.length() < 5){
			ip = "localhost";
		}
		TestTCPClientFrame clientFrame = null;
		try{
			clientFrame= new TestTCPClientFrame(name, ip);
		}catch(Exception e){
			System.exit(2);
		}
		clientFrame.setVisible(true);
	}
}


class MessageManagerTCP_x implements Runnable
{
	private ObjectInputStream in;
	private boolean forever = true;
	private JTextArea pane;
	private int errors = 0;
	public MessageManagerTCP_x(ObjectInputStream in,  JTextArea pane) throws IOException
	{
		this.in= in;
		this.pane = pane;	
	}
	
	public void close(){
		forever = false;
	}
	
	public void run()
	{
		System.out.println("Message manager is up ...");
		while(forever){
			try{
				SimpleTextMessage m = (SimpleTextMessage)(this.in.readObject());
				if(m.getMessage().startsWith("END")){
					forever = false;
				}else{
					pane.append(m.getSenderName()+"] "+ m.getMessage()+"\n");
					pane.setCaretPosition(pane.getText().length());
				}
			}catch(Exception e){
				errors++;
				System.out.println("Error: This is only for text messaging.");
				e.printStackTrace();
				if(errors >= 5){
					forever = false;
				}
			}
		}
		System.out.println("message manager retired");
		System.exit(1);
	}
}
