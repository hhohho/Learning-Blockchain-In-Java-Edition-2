package mdsky.applications.blockchain;
import java.net.Socket;
import java.net.ServerSocket;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TestTCPServerCenter
{
	public static final int port = 8888;
	private static boolean forever = true;
	private static ConcurrentLinkedQueue<SimpleTextMessage> messageQueue = new ConcurrentLinkedQueue<SimpleTextMessage>();
	private static 	Hashtable<String, UserChannelInfo> users = new Hashtable<String, UserChannelInfo>();
	public static void main(String[] args) throws IOException, ClassNotFoundException
	{	 
		ServerSocket server = new ServerSocket(port);
		ServerMessageManager smm = new ServerMessageManager(messageQueue, users);
		Thread ts = new Thread(smm);
		ts.start();
		//A server should be on forever.
		//But we do not want the server to be on forever if there is no incoming message
		//for a long time as this is for demonstration purpose only
		//The timeout is 1 hour. If you do not want the server to time out, please delete the
		//statement immediately below: server.setSoTimeout(1000*60*60);
		server.setSoTimeout(1000*60*60);
		while(forever){
			try{
				System.out.println("server is listening now");
				Socket socket = server.accept();
				System.out.println("got a connection, identifying name");
				UserChannelInfo channel = new UserChannelInfo(socket, messageQueue);
				System.out.println("user is: " + channel.getName());
				users.put(channel.getName(), channel);
				Thread t = new Thread(channel);
				t.start();
			}catch(java.net.SocketTimeoutException te){
				System.out.println("server time out. Byebye");
				forever = false;
			}
		}
		server.close();
		System.out.println("server closed");
		System.exit(0);
	}
	
	public static synchronized UserChannelInfo removeUserChannel(String name)
	{
		 return users.remove(name);
	}
}


class UserChannelInfo implements Runnable
{
	private ObjectInputStream input;
	private ObjectOutputStream output;
	private Socket socket;
	private String name = null;
	private ConcurrentLinkedQueue<SimpleTextMessage> messageQueue;
	private boolean forever = true;
	private int errors = 0;
	public UserChannelInfo(Socket socket, ConcurrentLinkedQueue<SimpleTextMessage> messageQueue) throws IOException, ClassNotFoundException
	{
		this.socket = socket;
		this.output = new ObjectOutputStream(socket.getOutputStream());
		this.input = new ObjectInputStream(socket.getInputStream());
		this.name = (String)(this.input.readObject());
		this.messageQueue = messageQueue;
		this.messageQueue.add(new SimpleTextMessage("System", this.name+" joined."));
	}
	
	public void run()
	{
		System.out.println("The communication channel for " + this.name +" is up.");
		while(forever){
			try{
				Thread.sleep(500);
			}catch(Exception e2){
				errors++;
			}
			try{
				String mesg = (String)input.readObject();
				if(mesg.startsWith("END")){
					//ending message to close the channel
					forever = false;
				}else{
					//add this message to the queues
					SimpleTextMessage sm = new SimpleTextMessage(this.getName(), mesg);
					this.messageQueue.add(sm);
				}
			}catch(Exception e){
				errors++;
				if(errors>=5){
					//closing this channel
					System.out.println("server is closing the channel for " + this.name 
							+" because of error: "+ e.getMessage());
					forever = false;
					sendMessage(new SimpleTextMessage("Server", "END"));
				}
			}
		}
		//remove self from the hashtable
		UserChannelInfo U = TestTCPServerCenter.removeUserChannel(this.getName());
		if(U != null){
			//let everyone know that U is off
			SimpleTextMessage sm = new SimpleTextMessage("System", U.getName() + " left.");
			this.messageQueue.add(sm);
		}
	}
	
	public void sendMessage(SimpleTextMessage message)
	{
		try{
			this.output.writeObject(message);
		}catch(Exception e){
			errors++;
			if(errors >= 5){
				throw new RuntimeException(e);
			}
		}
	}
	
	public String getName(){
		return this.name;
	}
}


class ServerMessageManager implements Runnable
{
	private ConcurrentLinkedQueue<SimpleTextMessage> messageQueue = null;
	private Hashtable<String, UserChannelInfo> users = null;
	private boolean forever = true;
	public ServerMessageManager(ConcurrentLinkedQueue<SimpleTextMessage> messageQueue,
												Hashtable<String, UserChannelInfo> users)
	{
		this.messageQueue = messageQueue;
		this.users = users;
	}
	
	public void run()
	{
		System.out.println("ServerMessageManager is up, too, waiting for incoming messages");
		//using polling, which is not efficient
		while(forever){
			try{
				Thread.sleep(100);
			}catch(Exception e){
				
			}
			//process the messages in the queue
			while(!messageQueue.isEmpty()){
				SimpleTextMessage sm = messageQueue.poll();
				//send to other users
				Enumeration<UserChannelInfo> all = users.elements();
				while(all.hasMoreElements()){
					UserChannelInfo user = all.nextElement();
					//assume that everyone has a unique name
					user.sendMessage(sm);
				}
			}
		}
	}
	
}