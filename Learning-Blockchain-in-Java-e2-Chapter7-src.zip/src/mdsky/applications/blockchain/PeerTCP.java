package mdsky.applications.blockchain;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class PeerTCP
{
	public static final int port = 8888;
	public static void main(String[] args) throws IOException
	{
		Scanner keyboard = new Scanner(System.in);
		System.out.println("What you want to call your friend?");
		String friendName = keyboard.nextLine();
		System.out.println("What is your own name?");
		String self = keyboard.nextLine().trim();
		PeerTCPOutgoingMessageManager outgoing = new PeerTCPOutgoingMessageManager(friendName, self);
		outgoing.start();
		ServerSocket server = new ServerSocket(port);
		System.out.println("server is listening now");
		Socket socket = server.accept();
		InetAddress clientAddress = socket.getInetAddress();
		System.out.println(friendName + " is from "+clientAddress.getHostAddress());
		System.out.println("Incoming connection established, receiving messages now.");
		PeerTCPIncomingMessageManager pi = new PeerTCPIncomingMessageManager(socket, friendName);
		pi.start();
		server.close();
	}
}


class PeerTCPIncomingMessageManager extends Thread
{
	private ObjectInputStream in;
	private ObjectOutputStream out;
	private boolean forever = true;
	private String friendName;
	public PeerTCPIncomingMessageManager(Socket socket, String friendName) throws IOException
	{
		//In TCP socket, you must create the outputstream first
		//then the inputstream. The order is critical
		this.out = new ObjectOutputStream(socket.getOutputStream());
		this.in = new ObjectInputStream(socket.getInputStream());
		this.friendName = friendName;
	}
	
	public void run()
	{
		System.out.println("PeerIncomingMessageManager is up ...");
		while(forever){
			try{
				String m = (String)(this.in.readObject());
				System.out.println(this.friendName+"]: " + m);
				if(m.trim().startsWith("END")){
					forever = false;
				}
			}catch(Exception e){
				System.out.println("Error: This is only for text messaging.");
				forever = false;
			}
		}
		System.out.println("PeerIncomingMessageManager retired");
		try{
			this.out.close();
			this.in.close();
		}catch(IOException ioe){
			//
		}
		System.exit(1);
	}
}


class PeerTCPOutgoingMessageManager extends Thread
{
	private ObjectInputStream in;
	private ObjectOutputStream out;
	private boolean forever = true;
	private String friendName;
	private String self;
	private Scanner keyboard;
	public PeerTCPOutgoingMessageManager(String friendName, String self)
	{
		this.friendName = friendName;
		this.self = self;
		keyboard = new Scanner(System.in);
	}
	
	public void run()
	{
		System.out.println("Outgoing connection has not established. please enter your peer friend's IP address:");
		String ip = keyboard.nextLine();
		try{
			Socket socket = new Socket(ip, PeerTCP.port);
			//In TCP socket, you must create the outputstream first
			//then the inputstream. The order is critical
			this.out = new ObjectOutputStream(socket.getOutputStream());
			this.in = new ObjectInputStream(socket.getInputStream());
		}catch(IOException ioe){
			ioe.printStackTrace();
			System.exit(1);
		}
		System.out.println("Outgoing connection established. Feel free to send " + friendName+" messages.");
		while(forever){
			try{
				Thread.sleep(500);
				try{
					String mesg = keyboard.nextLine();
					System.out.println(self+"]: " + mesg);
					this.out.writeObject(mesg);
					if(mesg.trim().startsWith("END")){
						forever = false;
					}
				}catch(Exception e){
					forever = false;
				}
			}catch(InterruptedException ie){
				//do nothing
			}
		}
		try{
			this.out.close();
			this.in.close();
		}catch(IOException ioe){
			//
		}
		System.out.println("PeerIncomingMessageManager retired");
		System.exit(1);
	}
}