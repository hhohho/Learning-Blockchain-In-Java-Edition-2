package mdsky.applications.blockchain;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Signature;

public class TestSignature {

	public static void main(String[] args) throws Exception
	{
		String msg = "If you never come, how do I age alone?";
		KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
		//initialize the KeyPairGenerator by specifying its key size
		kpg.initialize(2048);
		//generate the key pair now
		KeyPair pair = kpg.generateKeyPair();
		
		Signature sig = Signature.getInstance("SHA256withRSA");
		//initializing the Signature instance to sign the digital binary data
		sig.initSign(pair.getPrivate());
		sig.update(msg.getBytes());
		byte[] digitalSignature = sig.sign();
		//take a peek at the signature
		System.out.println(new String(digitalSignature));
		//now, suppose that the receiver got the data with signature
		Signature sig2 = Signature.getInstance("SHA256withRSA");
		sig2.initVerify(pair.getPublic());
		sig2.update(msg.getBytes());
		boolean verified = sig2.verify(digitalSignature);
		System.out.println("verified="+verified);

	}

}
