package mdsky.applications.blockchain;

import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
//import java.security.Signature;
//import javax.crypto.Cipher;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
//import java.security.Key;
//import javax.crypto.KeyGenerator;
//import java.security.SecureRandom;
//import java.security.SecureRandom;
//import java.security.KeyPair;
//import java.security.KeyPairGenerator;
//import java.security.MessageDigest;
//import java.security.PrivateKey;
//import java.security.PublicKey;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
import java.io.*;
import java.util.Base64;


public class UtilityMethods 
{
	private static long uniqueNumber = 0;
	
	public static long getUniqueNumber(){
		return UtilityMethods.uniqueNumber++;
	}
	
	public static KeyPair generateKeyPair()
	{
		try{
			KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
			kpg.initialize(2048);
			KeyPair pair = kpg.generateKeyPair();
			return pair;
		}catch(java.security.NoSuchAlgorithmException e){
			throw new RuntimeException(e);
		}
	}	
	
	public static byte[] generateSignature(PrivateKey privateKey, String message)
	{
		try{
			Signature sig = Signature.getInstance("SHA256withRSA");
			//initializing the Signature instance to sign the digital binary data
			sig.initSign(privateKey);
			sig.update(message.getBytes());
			return sig.sign();
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	
	public static boolean verifySignature(PublicKey publicKey, byte[] signature, String message)
	{
		try{
			Signature sig2 = Signature.getInstance("SHA256withRSA");
			sig2.initVerify(publicKey);
			sig2.update(message.getBytes());
			return sig2.verify(signature);
		}catch(Exception e){
			//throw new RuntimeException(e);
			e.printStackTrace();
			return false;
		}
	}
	
	public static String messageDigestSHA256_toString(String message)
	{
		return Base64.getEncoder().encodeToString(messageDigestSHA256_toBytes(message));
	}
	
	public static byte[] messageDigestSHA256_toBytes(String message)
	{
		try{
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			//the method update() only accept a byte array
			md.update(message.getBytes());
			return md.digest();
		}catch(java.security.NoSuchAlgorithmException e){
			throw new RuntimeException(e);
		}
	}
	
	public static long getTimeStamp()
	{
		return java.util.Calendar.getInstance().getTimeInMillis();
	}
	
	public static String toBinaryString(byte[] hash)
	{
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<hash.length; i++){
			int x = ((int)hash[i])+128; //making it unsigned
			String s = Integer.toBinaryString(x);
			while(s.length() < 8){
				s = "0"+s;
			}
			sb.append(s);
		}
		return sb.toString();
	}
	
	public static boolean hashMeetsDifficultyLevel(String hash, int difficultyLevel)
	{
		char[] c = hash.toCharArray();
		for(int i=0; i<difficultyLevel; i++){
			if(c[i] != '0'){
				return false;
			}
		}
		return true;
	}
	
	public static String getKeyString(Key key)
	{
		return Base64.getEncoder().encodeToString(key.getEncoded());
	}
	
	
	public static void displayTransaction(Transaction T, PrintStream out, int level)
	{
		displayTab(out, level, "Transaction{");
		displayTab(out, level+1, "ID: " + T.getHashID());
		displayTab(out, level+1, "sender: " + UtilityMethods.getKeyString(T.getSender()));
		displayTab(out, level+1, "fundToBeTransferred total: " + T.getTotalFundToTransfer());
		displayTab(out, level+1, "Input:");
		for(int i=0; i<T.getNumberOfInputUTXOs(); i++){
			UTXO ui = T.getInputUTXO(i);
			displayUTXO(ui, out, level + 2);
		}
		
		displayTab(out, level+1, "Output:");
		for(int i=0; i<T.getNumberOfOutputUTXOs()-1; i++){
			UTXO ut = T.getOuputUTXO(i);
			displayUTXO(ut, out, level+2);
		}
		UTXO change = T.getOuputUTXO(T.getNumberOfOutputUTXOs()-1);
		displayTab(out, level+1, "transaction fee: "+ Transaction.TRANSACTION_FEE);
		displayTab(out, level+1,"change: "+change.getFundTransferred());
		boolean b = T.verifySignature();
		displayTab(out, level+1, "signature verification: " + b);
		displayTab(out, level, "}");
	}
	
	public static void displayTab(PrintStream out, int level, String s)
	{
		for(int i=0; i<level; i++){
			out.print("\t");
		}
		out.println(s);
	}
	
	public static void displayUTXO(UTXO ux, PrintStream out, int level)
	{
		displayTab(out, level, "fund: "+ ux.getFundTransferred()+", receiver: "+UtilityMethods.getKeyString(ux.getReceiver()));
	}
}

