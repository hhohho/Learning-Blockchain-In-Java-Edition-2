package mdsky.applications.blockchain;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import javax.crypto.Cipher;

public class TestCipher_2 {

	public static void main(String[] args) throws Exception
	{
		String msg = "If you were a drop of tear in my eyes, I will never cry, because of I am afraid of losing you. "
				+ "If you were a drop of tear in my eyes, I will never cry, because of I am afraid of losing you. "
				+"If you were a drop of tear in my eyes, I will never cry, because of I am afraid of losing you. ";
		/*
		for(int i=0; i<10; i++){
			msg += msg;
		}
		*/
		/*
		 * JDK KeyPairGenerator supports three different algorithms, based on Oracle Java API
		 * 1. DiffieHellman, 1024 bit key size
		 * 2. DSA, 1024 bit key size
		 * 3. RSA, 1024 or 2048 bit key size
		 */
		KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
		//initialize the KeyPairGenerator by specifying its key size
		kpg.initialize(4096);
		//generate the key pair now
		KeyPair pair = kpg.generateKeyPair();
		//at this point, we need a Cipher object that supports RSA algorithm. BTW, Cipher does not support DSA algorithm!
		//Cipher cipher2 = Cipher.getInstance("RSA/ECB/PKCS1Padding"); //this works well, too
		Cipher cipher2 = Cipher.getInstance("RSA");
		//however, using RSA publickey to encrypt data with padding, the message cannot exceed 245 bytes!!!!
		cipher2.init(Cipher.ENCRYPT_MODE, pair.getPublic());
		System.out.println(msg);
		byte[] bb = cipher2.doFinal(msg.getBytes());
		//once it is encoded by the public key, we know that it can only be decoded by using the private key.
		//Let's check it out
		cipher2.init(Cipher.DECRYPT_MODE, pair.getPrivate());
		byte[] b2 = cipher2.doFinal(bb);
		System.out.println("after using private key to decode: ");
		System.out.println(new String(b2));

		System.out.println(msg.getBytes().length+"|"+bb.length+"|"+b2.length);
	}

}
