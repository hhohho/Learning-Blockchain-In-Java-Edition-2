package mdsky.applications.blockchain;

public class TestHashing{
	public static void main(String[] args){
		String mesg = "If you are a drop of tears in my eyes";
		String hash = UtilityMethods. messageDigestSHA256_toString(mesg);
		System.out.println(hash);
	}
}
