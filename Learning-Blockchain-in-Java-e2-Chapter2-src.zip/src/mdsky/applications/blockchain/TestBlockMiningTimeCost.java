package mdsky.applications.blockchain;
import java.io.PrintWriter;

public class TestBlockMiningTimeCost {
	public static void main(String[] args) throws Exception
	{
		PrintWriter out = new PrintWriter("miningTime-difficultyLevel.csv");
		for(int i=15; i<=28; i++){
			long start = System.currentTimeMillis();
			int N = 30;
			for(int z=0; z<N; z++){
				Block b = new Block("0", i);
				for(int t=0; t<10; t++){
					b.addTransaction("Transaction"+t);
				}
				b.mineTheBlock();
			}
			long end = System.currentTimeMillis();
			long time = end - start;
			out.println(i+","+(time/N));
			out.flush();
		}
		out.close();
	}

}
