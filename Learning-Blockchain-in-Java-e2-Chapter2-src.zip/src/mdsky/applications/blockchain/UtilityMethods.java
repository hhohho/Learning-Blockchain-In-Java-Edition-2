package mdsky.applications.blockchain;

import java.security.MessageDigest;
//import java.security.Key;
//import javax.crypto.KeyGenerator;
//import java.security.SecureRandom;
//import java.security.SecureRandom;
//import java.security.KeyPair;
//import java.security.KeyPairGenerator;
//import java.security.MessageDigest;
//import java.security.PrivateKey;
//import java.security.PublicKey;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.io.*;
import java.util.Base64;


public class UtilityMethods 
{
	public static String messageDigestSHA256_toString(String message)
	{
		return Base64.getEncoder().encodeToString(messageDigestSHA256_toBytes(message));
	}
	
	public static byte[] messageDigestSHA256_toBytes(String message)
	{
		try{
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			//the method update() only accept a byte array
			md.update(message.getBytes());
			return md.digest();
		}catch(java.security.NoSuchAlgorithmException e){
			throw new RuntimeException(e);
		}
	}
	
	public static long getTimeStamp()
	{
		return java.util.Calendar.getInstance().getTimeInMillis();
	}
	
	public static String toBinaryString(byte[] hash)
	{
		StringBuilder sb = new StringBuilder();
		for(int i=0; i<hash.length; i++){
			int x = ((int)hash[i])+128; //making it unsigned
			String s = Integer.toBinaryString(x);
			while(s.length() < 8){
				s = "0"+s;
			}
			sb.append(s);
		}
		return sb.toString();
	}
	
	public static boolean hashMeetsDifficultyLevel(String hash, int difficultyLevel)
	{
		char[] c = hash.toCharArray();
		for(int i=0; i<difficultyLevel; i++){
			if(c[i] != '0'){
				return false;
			}
		}
		return true;
	}
}

