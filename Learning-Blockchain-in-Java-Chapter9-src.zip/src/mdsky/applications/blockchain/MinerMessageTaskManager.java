package mdsky.applications.blockchain;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;

public class MinerMessageTaskManager extends WalletMessageTaskManager implements Runnable
{
	private boolean miningAction = true;
	private ArrayList<Transaction> existingTransactions = new ArrayList<Transaction>();
	private WalletConnectionAgent agent;
	
	public MinerMessageTaskManager(WalletConnectionAgent agent, Miner miner, 
			ConcurrentLinkedQueue<Message> messageQueue)
	{
		super(agent, miner, messageQueue);
		this.agent = agent;
	}
	
	protected synchronized void resetMiningAction(){
		this.miningAction = true;
	}
	
	protected synchronized boolean getMiningAction(){
		return this.miningAction;
	}
	
	protected synchronized void raiseMiningAction(){
		this.miningAction = false;
	}
	
	protected void receiveQueryForBlockchainBroadcast(MessageAskForBlockchainBroadcast mabcb)
	{
		PublicKey receiver = mabcb.getSenderKey();
		Blockchain bc = myWallet().getLocalLedger().copy_NotDeepCopy();
		
		MessageBlockchainPrivate message = new MessageBlockchainPrivate(bc, 	
						myWallet().getPublicKey(), receiver);
		boolean b = this.agent.sendMessage(message);
		if(b){
			System.out.println(myWallet().getName()+": sent local blockchain to the requester, chain size="
								+message.getMessageBody().size() + "|"+message.getInfoSize());
		}else{
			System.out.println(myWallet().getName()+": failed to send local blockchain to the requester");
		}
	}
	
	
	protected void receiveMessageTransactionBroadcast(MessageTransactionBroadcast mtb)
	{
		Transaction ts = mtb.getMessageBody();
		//first, make sure that this transaction does not exist in the current pool
		for(int i=0; i<this.existingTransactions.size(); i++){
			if(ts.equals(this.existingTransactions.get(i))){
				return;
			}
		}
		
		//add this into the existing storage
		if(!myWallet().validateTransaction(ts)){
			System.out.println("Miner "+ myWallet().getName()+" found an invalid transaction. Should broadcast it though");
			return;
		}
		this.existingTransactions.add(ts);
		//check if it meets the requirement to build a block
		if(this.existingTransactions.size() >= Configuration.blockTransactionNumberLowerLimit() 
				&& this.getMiningAction() ){
			this.raiseMiningAction();
			System.out.println(myWallet().getName()+" has enough transactions to mine the block now, " 
					+"mining_action_block_size requirement meets. Start mining a new block");
			//Modification in Chapter 9: 
			//copy transactions into another arraylist for the work to build a block.
			//Remove those transactions from the original pool once copied.
			ArrayList<Transaction> tts = new ArrayList<Transaction>();
			for(int i=0,j=0; i<this.existingTransactions.size() && j<Configuration.blockTransactionNumberUpperLimit(); i++,j++){
				tts.add(this.existingTransactions.get(i));
				this.existingTransactions.remove(i);
				i--;
			}
			MinerTheWorker worker = new MinerTheWorker(myWallet(), this, this.agent, tts);
			Thread miningThread = new Thread(worker);
			miningThread.start();
			//Modification in chapter 9:
			//this.existingTransactions = new ArrayList<Transaction>(); 		
		}
	}
	
	/**
	 * Modification in chapter 9:
	 * Overwrite this method so that when a block is accepted, the miner needs to 
	 * re-examine its transaction pool in case some existing transactions should be
	 * invalidated by this newly accepted block.
	 */
	protected boolean receiveMessageBlockBroadcast(MessageBlockBroadcast mbb)
	{
		boolean b = super.receiveMessageBlockBroadcast(mbb);
		if(b){
			Block block = mbb.getMessageBody();
			//now examine if any transactions in the pool also exist inside this block
			//If does, remove it from the pool
			for(int i=0; i<block.getTotalNumberOfTransactions(); i++){
				Transaction t = block.getTransaction(i);
				//test if t exists in the pool
				for(int j=0; j<this.existingTransactions.size(); j++){
					Transaction t2 = this.existingTransactions.get(j);
					if(t.equals(t2)){
						this.existingTransactions.remove(j);
						break;
					}
				}
			}
		}
		return b;
	}
	
	/**
	 * Override the existing method to make sure that the returned wallet is a miner.
	 */
	protected Miner myWallet(){
		return (Miner)(super.myWallet());
	}
}

