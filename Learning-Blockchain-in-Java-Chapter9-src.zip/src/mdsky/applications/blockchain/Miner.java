package mdsky.applications.blockchain;

public class Miner extends Wallet
{
	public Miner(String minerName, String password) 
	{
		super(minerName, password);
	}
	

	public boolean mineBlock(Block block)
	{
		if((block.mineTheBlock(this.getPublicKey()))){
			//After mining, sign the block
			byte[] signature = UtilityMethods.generateSignature(this.getPrivateKey(), block.getHashID());
			return block.signTheBlock(this.getPublicKey(), signature);
		}else{
			return false;
		}
	}
	
	public boolean addTransaction(Transaction ts, Block block)
	{
		if(this.validateTransaction(ts)){
			return block.addTransaction(ts, this.getPublicKey());
		}else{
			return false;
		}
	}

	/**
	 * Deleting a transaction from a block must meet two conditions:
	 * <li>Only the block creator can delete a transaction from the block
	 * <li>The deletion action must happen before the block is mined and signed.
	 * </li>
	 * @param ts
	 * @param block
	 * @return
	 */
	public boolean deleteTransaction(Transaction ts, Block block)
	{
		return block.deleteTransaction(ts, this.getPublicKey());
	}
	
	/**
	 * The reward transaction does not have input. So, the transaction must be manually prepared
	 * by the miner.
	 * @param block
	 * @return
	 */
	public boolean generateRewardTransaction(Block block)
	{
		double amount = Configuration.blockMiningReward()+block.getTransactionFeeAmount();
		Transaction T = new Transaction(this.getPublicKey(), this.getPublicKey(), amount, null);
		UTXO ut = new UTXOAsMiningReward(T.getHashID(), T.getSender(), this.getPublicKey(), amount);
		T.addOutputUTXO(ut);
		T.signTheTransaction(this.getPrivateKey());
		return block.generateRewardTransaction(this.getPublicKey(), T);
	}
	
	/**
	 * In this implementation, a block is created by the miner only. Thus, different miner can be working on
	 * different blocks. For example, assume the blockchain has 10 blocks already. Now it is time to work on
	 * 11th block. Miner A might be constructing his 11th block with Transactions T1, T2, T3, while miner
	 * B might be constructing her 11th block with Transaction T1, T4, T5, and T6.
	 * As blockchain is a distributed system, there should not be a control enforcing every miner to mine
	 * the same block with the same transactions.
	 * @param ledger
	 * @param difficultLevel
	 * @return
	 */
	public Block createNewBlock(Blockchain ledger, int difficultLevel)
	{
		Block b = new Block(ledger.getLastBlock().getHashID(), difficultLevel, this.getPublicKey());
		return b;
	}	
	
}
