package mdsky.applications.blockchain;

import java.security.PrivateKey;
import java.security.PublicKey;

public class MessageTextCloseConnectionPrivate extends MessageTextPrivate
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	public MessageTextCloseConnectionPrivate(PrivateKey prikey, 
					PublicKey senderKey, String senderName, PublicKey receiver)
	{
		super(Message.TEXT_CLOSE, prikey, senderKey, senderName, receiver);
	}
	

	public int getMessageType(){
		return Message.TEXT_PRIVATE_CLOSE_CONNECTION;
	}

}
