package mdsky.applications.blockchain;

import java.security.PrivateKey;
import java.security.PublicKey;

public class MessageTextQueryAddressPrivate extends MessageTextPrivate
{
	/**
	 * later, any modification of this class (different version) should update the serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	public MessageTextQueryAddressPrivate(PrivateKey prikey, 
					PublicKey senderKey, String senderName, PublicKey receiver)
	{
		super(Message.TEXT_ASK_ADDRESSES, prikey, senderKey, senderName, receiver);
	}
	

	public int getMessageType(){
		return Message.TEXT_PRIVATE_QUERY_ADDRESSES;
	}

}
